'use strict';
(function registerRawCopyPanel() {
  if (typeof chrome === 'undefined' ||
      !chrome.devtools ||
      !chrome.devtools.panels ||
      typeof chrome.devtools.panels.create !== 'function') {
    console.warn('[Raw Copy] chrome.devtools.panels 不可用，跳过面板注册。');
    return;
  }
  var PANEL_TITLE = 'Raw Copy';
  var PANEL_ICON = 'icons/icon32.png';
  var PANEL_PAGE = 'panel.html';
  chrome.devtools.panels.create(PANEL_TITLE, PANEL_ICON, PANEL_PAGE, function (panel) {
    console.log('[Raw Copy] 面板已注册：' + PANEL_TITLE + ' → ' + PANEL_PAGE);
    if (panel && typeof panel.onShown === 'object') {
      console.log('[Raw Copy] panel 对象已就绪。');
    }
  });
})();