import { t } from './src/i18n.js';
import { createStore } from './src/store.js';
import { installCapture } from './src/capture.js';
import { applyFilter, collectOptions } from './src/filter.js';
import { applyHide } from './src/hidefilter.js';
import { splitUrl } from './src/urlparts.js';
import { createVirtualList } from './src/render.js';
import { createMultiSelection } from './src/multiselection.js';
import {
  buildCopyText,
  MODE_A,
  MODE_B,
} from './src/formatter.js';
import { buildBulkCopyText } from './src/bulkformatter.js';
import { buildDetailText, createDetailView } from './src/detail.js';
import { copyText } from './src/clipboard.js';
import { classifyBody, isOverThreshold } from './src/content.js';
import {
  resolveRowId,
  createMenuModel,
  clampPosition,
  CTX_ACTION,
} from './src/contextmenu.js';
const TOAST_DURATION_MS = 2400;
const STORE_CAPACITY = 1000;
const PENDING_TIMEOUT_MS = 3000;
const LIST_OVERSCAN = 5;
const FALLBACK_ROW_HEIGHT = 28;
export const els = {
  toolbar: document.querySelector('#toolbar'),
  search: document.querySelector('#search'),
  filterMethod: document.querySelector('#filter-method'),
  filterStatus: document.querySelector('#filter-status'),
  filterType: document.querySelector('#filter-type'),
  hideToggle: document.querySelector('#hide-static-toggle'),
  listCount: document.querySelector('#list-count'),
  clearBtn: document.querySelector('#clear-btn'),
  list: document.querySelector('#list'),
  listBody: document.querySelector('#list-body'),
  empty: document.querySelector('#empty'),
  copyActions: document.querySelector('#copy-actions'),
  copyBtn: document.querySelector('#copy-btn'),
  copyBtnA: document.querySelector('#copy-btn-a'),
  copyBtnB: document.querySelector('#copy-btn-b'),
  copyCurlBtn: document.querySelector('#copy-curl-btn'),
  multiselectActions: document.querySelector('#multiselect-actions'),
  selectAllBtn: document.querySelector('#select-all-btn'),
  copySelectedBtn: document.querySelector('#copy-selected-btn'),
  selectedCount: document.querySelector('#selected-count'),
  contextMenu: document.querySelector('#context-menu'),
  detailPane: document.querySelector('#detail-pane'),
  detailBody: document.querySelector('#detail-body'),
  detailClose: document.querySelector('#detail-close'),
  detailBackdrop: document.querySelector('[data-detail-backdrop]'),
  toast: document.querySelector('#toast'),
  privacyLink: document.querySelector('#privacy-link'),
};
function normalizeMode(mode) {
  return mode === MODE_B ? MODE_B : MODE_A;
}
let toastTimer = null;
let selectedId = null;
let activeSelection = null;
let getSelectedImpl = function noSelection() {
  return null;
};
let activeStore = null;
export function getSelected() {
  return getSelectedImpl();
}
let getSelectedIdsImpl = function noSelectionIds() {
  return [];
};
let copySelectionImpl = function noCopySelection() {
  return Promise.resolve({ ok: false, count: 0, reason: 'inactive' });
};
export function getSelectedIds() {
  return getSelectedIdsImpl();
}
export function copySelection(mode) {
  return copySelectionImpl(mode);
}
let openContextMenuImpl = function noContextMenu() {
  return undefined;
};
export function openContextMenu(event) {
  return openContextMenuImpl(event);
}
const DETAIL_COPY_BTN_ID = 'detail-copy-btn';
let openDetailImpl = function noDetail() {
  return false;
};
let closeDetailImpl = function noDetailClose() {
  return false;
};
export function openDetail(id) {
  return openDetailImpl(id);
}
export function closeDetail() {
  return closeDetailImpl();
}
let lastCopyText = null;
function isRecordPending(record) {
  return !!(
    activeStore &&
    typeof activeStore.isPending === 'function' &&
    record &&
    record.id !== undefined &&
    record.id !== null &&
    activeStore.isPending(record.id)
  );
}
function resolveResponseBodyText(record) {
  if (!record) {
    return '';
  }
  if (isRecordPending(record)) {
    return t('content.fetching');
  }
  const classified = classifyBody(record.responseContent);
  if (classified.kind === 'text' || classified.kind === 'base64-text') {
    return typeof classified.text === 'string' ? classified.text : '';
  }
  if (classified.kind === 'binary' || classified.kind === 'base64-omitted') {
    return typeof classified.placeholder === 'string' ? classified.placeholder : '';
  }
  return t('content.unavailable');
}
export function buildCurrentCopy(mode) {
  const record = getSelected();
  if (!record) {
    return null;
  }
  const responseBody = resolveResponseBodyText(record);
  return buildCopyText(record, normalizeMode(mode), { responseBody });
}
export function getLastCopyText() {
  return lastCopyText;
}
export function applyI18n(root) {
  const scope = root || document;
  const textNodes = scope.querySelectorAll('[data-i18n]');
  for (let i = 0; i < textNodes.length; i += 1) {
    const node = textNodes[i];
    node.textContent = t(node.getAttribute('data-i18n'));
  }
  const placeholderNodes = scope.querySelectorAll('[data-i18n-placeholder]');
  for (let i = 0; i < placeholderNodes.length; i += 1) {
    const node = placeholderNodes[i];
    node.setAttribute('placeholder', t(node.getAttribute('data-i18n-placeholder')));
  }
  const titleNodes = scope.querySelectorAll('[data-i18n-title]');
  for (let i = 0; i < titleNodes.length; i += 1) {
    const node = titleNodes[i];
    node.setAttribute('title', t(node.getAttribute('data-i18n-title')));
  }
  const ariaNodes = scope.querySelectorAll('[data-i18n-aria-label]');
  for (let i = 0; i < ariaNodes.length; i += 1) {
    const node = ariaNodes[i];
    node.setAttribute('aria-label', t(node.getAttribute('data-i18n-aria-label')));
  }
  return textNodes.length;
}
export function showToast(message, kind) {
  const el = els.toast;
  if (!el) {
    return;
  }
  el.textContent = typeof message === 'string' ? message : '';
  el.classList.remove('toast--info', 'toast--success', 'toast--error');
  el.classList.add('toast--' + (kind || 'info'));
  el.setAttribute('data-visible', 'true');
  if (toastTimer !== null) {
    clearTimeout(toastTimer);
  }
  toastTimer = setTimeout(function hideToast() {
    el.setAttribute('data-visible', 'false');
    toastTimer = null;
  }, TOAST_DURATION_MS);
}
function reportAsyncCopyError(err) {
  const reason = err && err.message ? err.message : t('toast.copyFailedUnknown');
  showToast(t('toast.copyFailed', { reason: reason }), 'error');
}
export function setEmptyState(visible) {
  if (els.empty) {
    els.empty.hidden = !visible;
  }
}
export function getCopyMode() {
  return MODE_A;
}
function readRowHeight() {
  if (typeof document !== 'undefined' && typeof getComputedStyle === 'function') {
    try {
      const computed = getComputedStyle(document.documentElement);
      const px = parseFloat(computed.getPropertyValue('--row-height'));
      if (Number.isFinite(px) && px > 0) {
        return px;
      }
    } catch (err) {
    }
  }
  return FALLBACK_ROW_HEIGHT;
}
function formatStatus(status) {
  return typeof status === 'number' && Number.isFinite(status) && status > 0
    ? String(status)
    : '-';
}
function formatTime(time) {
  if (typeof time !== 'number' || !Number.isFinite(time) || time < 0) {
    return '-';
  }
  return Math.round(time) + ' ms';
}
function formatSize(size) {
  if (typeof size !== 'number' || !Number.isFinite(size) || size < 0) {
    return '-';
  }
  if (size >= 1048576) {
    return (size / 1048576).toFixed(1) + ' MB';
  }
  if (size >= 1024) {
    return (size / 1024).toFixed(1) + ' KB';
  }
  return size + ' B';
}
function formatStarted(iso) {
  if (typeof iso !== 'string' || iso.length < 19) {
    return iso || '-';
  }
  return iso.slice(11, 19);
}
function ensureRowColumns(el) {
  if (el.children && el.children.length === 8) {
    return;
  }
  while (el.firstChild) {
    el.removeChild(el.firstChild);
  }
  const classes = [
    'col col--method',
    'col col--host',
    'col col--path',
    'col col--status',
    'col col--type',
    'col col--time',
    'col col--size',
    'col col--started',
  ];
  for (let i = 0; i < classes.length; i += 1) {
    const span = document.createElement('span');
    span.className = classes[i];
    span.setAttribute('role', 'gridcell');
    el.appendChild(span);
  }
}
function renderRow(record, el) {
  const rec = record || {};
  ensureRowColumns(el);
  const cols = el.children;
  const fullUrl = typeof rec.url === 'string' ? rec.url : '';
  const parts = splitUrl(fullUrl);
  cols[0].textContent = rec.method ? String(rec.method) : '?';
  cols[1].textContent = parts.host;
  cols[2].textContent = parts.path;
  cols[3].textContent = formatStatus(rec.status);
  cols[4].textContent = typeof rec.resourceType === 'string' ? rec.resourceType : '';
  cols[5].textContent = formatTime(rec.time);
  const content = rec.responseContent;
  cols[6].textContent = formatSize(content ? content.size : NaN);
  cols[7].textContent = formatStarted(rec.startedDateTime);
  if (typeof cols[1].setAttribute === 'function') {
    cols[1].setAttribute('title', fullUrl);
  }
  if (typeof cols[2].setAttribute === 'function') {
    cols[2].setAttribute('title', fullUrl);
  }
  let selected = false;
  if (activeSelection && rec.id !== undefined && rec.id !== null) {
    selected =
      typeof activeSelection.has === 'function' && activeSelection.has(rec.id)
        ? true
        : activeSelection.current() === rec.id;
  }
  if (el.classList) {
    if (selected) {
      el.classList.add('is-selected');
    } else {
      el.classList.remove('is-selected');
    }
  }
  if (typeof el.setAttribute === 'function') {
    el.setAttribute('aria-selected', selected ? 'true' : 'false');
  }
}
function setCopyButtonsEnabled(enabled) {
  const buttons = [els.copyBtn, els.copyBtnA, els.copyBtnB, els.copyCurlBtn];
  for (let i = 0; i < buttons.length; i += 1) {
    if (buttons[i]) {
      buttons[i].disabled = !enabled;
    }
  }
}
function createOption(value, label) {
  const option = document.createElement('option');
  option.value = value;
  option.textContent = label;
  return option;
}
function fillSelect(select, values) {
  const previous = select.value;
  while (select.firstChild) {
    select.removeChild(select.firstChild);
  }
  select.appendChild(createOption('', t('filter.all')));
  for (let i = 0; i < values.length; i += 1) {
    select.appendChild(createOption(values[i], values[i]));
  }
  select.value = previous;
}
const selectCache = new WeakMap();
function syncSelect(select, values) {
  if (!select) {
    return;
  }
  const key = values.join('\u0000');
  if (selectCache.get(select) === key) {
    return;
  }
  fillSelect(select, values);
  selectCache.set(select, key);
}
function init() {
  applyI18n(document);
  const store = createStore({ capacity: STORE_CAPACITY });
  activeStore = store;
  const rowHeight = readRowHeight();
  setCopyButtonsEnabled(false);
  getSelectedImpl = function resolveSelected() {
    if (selectedId === null) {
      return null;
    }
    return store.get(selectedId) || null;
  };
  let virtualList = null;
  const multi = createMultiSelection({
    ids: [],
    onChange: function onMultiSelectionChange(primaryId, index, ids) {
      selectedId = primaryId === undefined ? null : primaryId;
      setCopyButtonsEnabled(selectedId !== null || (Array.isArray(ids) && ids.length > 0));
      updateMultiToolbar();
      if (virtualList && typeof virtualList.refresh === 'function') {
        virtualList.refresh();
      }
    },
  });
  activeSelection = multi;
  let detailView = null;
  virtualList = createVirtualList({
    container: els.listBody,
    rowHeight,
    overscan: LIST_OVERSCAN,
    renderRow,
    onSelect: function onRowSelect(record, index) {
      multi.selectAt(index);
    },
  });
  let rafPending = false;
  let hideStatic = true;
  function readCriteria() {
    return {
      query: els.search ? els.search.value : '',
      method: els.filterMethod ? els.filterMethod.value : '',
      status: els.filterStatus ? els.filterStatus.value : '',
      resourceType: els.filterType ? els.filterType.value : '',
    };
  }
  function setEmptyMessage(titleKey, hintKey) {
    if (!els.empty) {
      return;
    }
    const title = els.empty.querySelector('.empty__title');
    if (title) {
      title.textContent = t(titleKey);
    }
    const hint = els.empty.querySelector('.empty__hint');
    if (hint) {
      hint.textContent = hintKey ? t(hintKey) : '';
      hint.hidden = !hintKey;
    }
  }
  function updateEmptyState(total, shown) {
    if (total === 0) {
      setEmptyMessage('empty.title', 'empty.hint');
      setEmptyState(true);
    } else if (shown === 0) {
      setEmptyMessage('empty.noMatch', null);
      setEmptyState(true);
    } else {
      setEmptyState(false);
    }
  }
  function refreshView() {
    const all = store.all();
    const options = collectOptions(all);
    syncSelect(els.filterMethod, options.methods);
    syncSelect(els.filterStatus, options.statuses);
    syncSelect(els.filterType, options.resourceTypes);
    const filtered = applyFilter(all, readCriteria());
    const visible = applyHide(filtered, hideStatic);
    const display = visible.slice().reverse();
    virtualList.setData(display);
    multi.setIds(
      display.map(function toId(record) {
        return record && record.id;
      }),
    );
    updateMultiToolbar();
    updateCount(filtered.length, display.length);
    updateEmptyState(all.length, display.length);
  }
  function updateCount(filteredCount, shownCount) {
    if (!els.listCount) {
      return;
    }
    if (filteredCount <= 0) {
      els.listCount.textContent = '';
      return;
    }
    const hidden = filteredCount - shownCount;
    els.listCount.textContent =
      hidden > 0
        ? t('list.hiddenCount', { shown: shownCount, total: filteredCount, hidden: hidden })
        : t('list.showCount', { shown: shownCount, total: filteredCount });
  }
  function requestRefresh() {
    if (rafPending) {
      return;
    }
    rafPending = true;
    const schedule =
      typeof requestAnimationFrame === 'function'
        ? requestAnimationFrame
        : function (cb) {
            return setTimeout(cb, 0);
          };
    schedule(function onFrame() {
      rafPending = false;
      refreshView();
    });
  }
  function scrollSelectionIntoView() {
    if (!virtualList || typeof virtualList.scrollToId !== 'function') {
      return;
    }
    const id = multi.current();
    if (id !== null) {
      virtualList.scrollToId(id);
    }
  }
  function onListBodyClick(event) {
    const target = event ? event.target : null;
    if (!target || typeof target.closest !== 'function' || !els.listBody) {
      return;
    }
    const row = target.closest('.row');
    if (!row) {
      return;
    }
    if (typeof els.listBody.contains === 'function' && !els.listBody.contains(row)) {
      return;
    }
    const index = Number(row.getAttribute('data-index'));
    if (!Number.isInteger(index) || index < 0) {
      return;
    }
    if (event && event.shiftKey && (event.ctrlKey || event.metaKey)) {
      multi.extendTo(index);
    } else if (event && event.shiftKey) {
      multi.rangeTo(index);
    } else if (event && (event.ctrlKey || event.metaKey)) {
      multi.toggleAt(index);
    } else {
      multi.selectAt(index);
    }
    if (els.list && typeof els.list.focus === 'function') {
      els.list.focus();
    }
  }
  function onListKeyDown(event) {
    if (!event) {
      return;
    }
    const key = event.key;
    if (key !== 'ArrowDown' && key !== 'ArrowUp') {
      return;
    }
    if (typeof event.preventDefault === 'function') {
      event.preventDefault();
    }
    multi.move(key === 'ArrowDown' ? 1 : -1);
    scrollSelectionIntoView();
  }
  function wireSelection() {
    if (els.listBody) {
      els.listBody.addEventListener('click', onListBodyClick);
    }
    if (els.list) {
      els.list.addEventListener('keydown', onListKeyDown);
    }
  }
  function updateMultiToolbar() {
    const count = multi.count();
    if (els.selectedCount) {
      els.selectedCount.textContent = t('multi.selectedCount', { count: count });
    }
    if (els.copySelectedBtn) {
      els.copySelectedBtn.textContent = t('multi.copySelected', { count: count });
      els.copySelectedBtn.disabled = count <= 0;
    }
  }
  function wireMultiToolbar() {
    if (els.multiselectActions) {
      els.multiselectActions.hidden = false;
    }
    if (els.selectAllBtn) {
      els.selectAllBtn.addEventListener('click', function onSelectAllClick() {
        multi.selectAll();
        if (els.list && typeof els.list.focus === 'function') {
          els.list.focus();
        }
      });
    }
    if (els.copySelectedBtn) {
      els.copySelectedBtn.addEventListener('click', function onCopySelectedClick() {
        const pendingCopy = copySelection(MODE_A);
        if (pendingCopy && typeof pendingCopy.catch === 'function') {
          pendingCopy.catch(reportAsyncCopyError);
        }
      });
    }
    updateMultiToolbar();
  }
  if (els.search) {
    els.search.addEventListener('input', requestRefresh);
  }
  if (els.filterMethod) {
    els.filterMethod.addEventListener('change', requestRefresh);
  }
  if (els.filterStatus) {
    els.filterStatus.addEventListener('change', requestRefresh);
  }
  if (els.filterType) {
    els.filterType.addEventListener('change', requestRefresh);
  }
  if (els.hideToggle) {
    els.hideToggle.checked = hideStatic;
    els.hideToggle.addEventListener('change', function onHideToggleChange() {
      hideStatic = !!els.hideToggle.checked;
      requestRefresh();
    });
  }
  if (els.clearBtn) {
    els.clearBtn.addEventListener('click', function onClearClick() {
      store.clear();
      if (els.list && typeof els.list.focus === 'function') {
        els.list.focus();
      }
    });
  }
  installCapture({ store, onAdd: requestRefresh, onUpdate: requestRefresh });
  function handleDetailEvict(id) {
    if (detailView && typeof detailView.onEvict === 'function' && detailView.onEvict(id)) {
      showToast(t('detail.evicted'), 'info');
    }
  }
  store.subscribe(function onStoreEvent(event) {
    if (!event) {
      return;
    }
    if (event.type === 'add' || event.type === 'update' || event.type === 'evict') {
      requestRefresh();
    }
    if (event.type === 'add' && event.evicted !== null && event.evicted !== undefined) {
      multi.onEvict(event.evicted);
      handleDetailEvict(event.evicted);
    } else if (event.type === 'evict') {
      multi.onEvict(event.id);
      handleDetailEvict(event.id);
    } else if (event.type === 'clear') {
      multi.clear();
      closeDetailPane();
      requestRefresh();
    }
  });
  wireSelection();
  wireMultiToolbar();
  function setModeButtonTitle(btn, hintKey) {
    if (btn && typeof btn.setAttribute === 'function') {
      btn.setAttribute('title', t(hintKey));
    }
  }
  function modeFromButton(btn) {
    const raw =
      btn && typeof btn.getAttribute === 'function'
        ? btn.getAttribute('data-copy-mode')
        : null;
    return raw === 'B' || raw === MODE_B ? MODE_B : MODE_A;
  }
  if (els.copyBtnA) {
    setModeButtonTitle(els.copyBtnA, 'mode.aHint');
    els.copyBtnA.addEventListener('click', function onCopyModeAClick() {
      const pendingCopy = runCurrentCopy(modeFromButton(els.copyBtnA));
      if (pendingCopy && typeof pendingCopy.catch === 'function') {
        pendingCopy.catch(reportAsyncCopyError);
      }
    });
  }
  if (els.copyBtnB) {
    setModeButtonTitle(els.copyBtnB, 'mode.bHint');
    els.copyBtnB.addEventListener('click', function onCopyModeBClick() {
      const pendingCopy = runCurrentCopy(modeFromButton(els.copyBtnB));
      if (pendingCopy && typeof pendingCopy.catch === 'function') {
        pendingCopy.catch(reportAsyncCopyError);
      }
    });
  }
  function confirmLargeCopy(size) {
    if (typeof confirm !== 'function') {
      return true;
    }
    try {
      return confirm(t('large.confirm', { size: size })) === true;
    } catch (err) {
      return true;
    }
  }
  async function runCurrentCopy(mode) {
    const effectiveMode = normalizeMode(mode);
    let record = getSelected();
    if (!record) {
      showToast(t('copy.hintSelect'), 'error');
      return;
    }
    if (isRecordPending(record)) {
      try {
        await activeStore.awaitPending(record.id, PENDING_TIMEOUT_MS);
      } catch (err) {
        showToast(t('copy.fetchingTimeout'), 'error');
        return;
      }
      record = getSelected();
      if (!record) {
        showToast(t('copy.hintSelect'), 'error');
        return;
      }
    }
    if (isOverThreshold(record.responseContent)) {
      const content = record.responseContent || {};
      const rawSize =
        typeof content.size === 'number' && Number.isFinite(content.size)
          ? content.size
          : typeof content.text === 'string'
            ? content.text.length
            : 0;
      if (!confirmLargeCopy(formatSize(rawSize))) {
        showToast(t('copy.cancelled'), 'info');
        return;
      }
    }
    const text = buildCurrentCopy(effectiveMode);
    if (text === null) {
      showToast(t('copy.hintSelect'), 'error');
      return;
    }
    lastCopyText = text;
    let result;
    try {
      result = await copyText(text);
    } catch (err) {
      result = { ok: false, via: 'none', reason: err && err.message ? err.message : String(err) };
    }
    if (result && result.ok) {
      showToast(t('toast.copied'), 'success');
      return;
    }
    const reason = result && result.reason ? result.reason : t('toast.copyFailedUnknown');
    showToast(t('toast.copyFailed', { reason: reason }), 'error');
  }
  if (els.copyBtn) {
    els.copyBtn.addEventListener('click', function onCopyMainClick() {
      const pendingCopy = runCurrentCopy(MODE_A);
      if (pendingCopy && typeof pendingCopy.catch === 'function') {
        pendingCopy.catch(reportAsyncCopyError);
      }
    });
  }
  function onDeferredCopyClick() {
    showToast(t('copy.notEnabled'), 'info');
  }
  if (els.copyCurlBtn) {
    els.copyCurlBtn.addEventListener('click', onDeferredCopyClick);
  }
  function confirmLargeSelection(count, size) {
    if (typeof confirm !== 'function') {
      return true;
    }
    try {
      return confirm(t('multi.largeConfirm', { count: count, size: size })) === true;
    } catch (err) {
      return true;
    }
  }
  function contentByteSize(record) {
    const content = record && record.responseContent ? record.responseContent : {};
    if (typeof content.size === 'number' && Number.isFinite(content.size)) {
      return content.size;
    }
    return typeof content.text === 'string' ? content.text.length : 0;
  }
  async function runCopySelection(mode) {
    const effectiveMode = normalizeMode(mode);
    const ids = multi.selectedIds();
    if (ids.length === 0) {
      showToast(t('copy.hintSelect'), 'error');
      return { ok: false, count: 0, reason: 'empty' };
    }
    function collectRecords() {
      const out = [];
      for (let i = 0; i < ids.length; i += 1) {
        const record = store.get(ids[i]);
        if (record) {
          out.push(record);
        }
      }
      return out;
    }
    let records = collectRecords();
    if (records.length === 0) {
      showToast(t('copy.hintSelect'), 'error');
      return { ok: false, count: 0, reason: 'empty' };
    }
    const pending = records.filter(isRecordPending);
    if (pending.length > 0) {
      try {
        for (let i = 0; i < pending.length; i += 1) {
          await activeStore.awaitPending(pending[i].id, PENDING_TIMEOUT_MS);
        }
      } catch (err) {
        showToast(t('copy.fetchingTimeout'), 'error');
        return { ok: false, count: records.length, reason: 'timeout' };
      }
      records = collectRecords();
      if (records.length === 0) {
        showToast(t('copy.hintSelect'), 'error');
        return { ok: false, count: 0, reason: 'empty' };
      }
    }
    let overCount = 0;
    let maxSize = 0;
    for (let i = 0; i < records.length; i += 1) {
      if (isOverThreshold(records[i].responseContent)) {
        overCount += 1;
        const size = contentByteSize(records[i]);
        if (size > maxSize) {
          maxSize = size;
        }
      }
    }
    if (overCount > 0 && !confirmLargeSelection(overCount, formatSize(maxSize))) {
      showToast(t('copy.cancelled'), 'info');
      return { ok: false, count: records.length, reason: 'cancelled' };
    }
    const text = buildBulkCopyText(records, effectiveMode, function resolveBody(record) {
      return resolveResponseBodyText(record);
    });
    lastCopyText = text;
    let result;
    try {
      result = await copyText(text);
    } catch (err) {
      result = { ok: false, via: 'none', reason: err && err.message ? err.message : String(err) };
    }
    if (result && result.ok) {
      showToast(t('toast.copied'), 'success');
      return { ok: true, count: records.length, reason: 'copied' };
    }
    const reason = result && result.reason ? result.reason : t('toast.copyFailedUnknown');
    showToast(t('toast.copyFailed', { reason: reason }), 'error');
    return { ok: false, count: records.length, reason: reason };
  }
  getSelectedIdsImpl = function resolveSelectedIds() {
    return multi.selectedIds();
  };
  copySelectionImpl = runCopySelection;
  let menuButtons = [];
  let menuActiveIndex = -1;
  let menuListenersAttached = false;
  function viewportSize() {
    const w =
      typeof window !== 'undefined' && Number(window.innerWidth) > 0
        ? Number(window.innerWidth)
        : 0;
    const h =
      typeof window !== 'undefined' && Number(window.innerHeight) > 0
        ? Number(window.innerHeight)
        : 0;
    return { w, h };
  }
  function clearMenuChildren(menu) {
    while (menu.firstChild) {
      menu.removeChild(menu.firstChild);
    }
  }
  function closeContextMenu() {
    const menu = els.contextMenu;
    if (menu) {
      menu.hidden = true;
      clearMenuChildren(menu);
    }
    menuButtons = [];
    menuActiveIndex = -1;
    detachMenuListeners();
  }
  function attachMenuListeners() {
    if (menuListenersAttached) {
      return;
    }
    menuListenersAttached = true;
    if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {
      document.addEventListener('mousedown', onMenuDocumentMouseDown);
      document.addEventListener('keydown', onMenuKeyDown);
    }
    if (els.list && typeof els.list.addEventListener === 'function') {
      els.list.addEventListener('scroll', onMenuScroll);
    }
    if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
      window.addEventListener('blur', onMenuWindowBlur);
    }
  }
  function detachMenuListeners() {
    if (!menuListenersAttached) {
      return;
    }
    menuListenersAttached = false;
    if (typeof document !== 'undefined' && typeof document.removeEventListener === 'function') {
      document.removeEventListener('mousedown', onMenuDocumentMouseDown);
      document.removeEventListener('keydown', onMenuKeyDown);
    }
    if (els.list && typeof els.list.removeEventListener === 'function') {
      els.list.removeEventListener('scroll', onMenuScroll);
    }
    if (typeof window !== 'undefined' && typeof window.removeEventListener === 'function') {
      window.removeEventListener('blur', onMenuWindowBlur);
    }
  }
  function onMenuDocumentMouseDown(event) {
    const menu = els.contextMenu;
    const target = event ? event.target : null;
    if (menu && target && typeof target.closest === 'function' && target.closest('#context-menu')) {
      return;
    }
    closeContextMenu();
  }
  function onMenuScroll() {
    closeContextMenu();
  }
  function onMenuWindowBlur() {
    closeContextMenu();
  }
  function activeMenuButton() {
    if (menuActiveIndex < 0 || menuActiveIndex >= menuButtons.length) {
      return null;
    }
    return menuButtons[menuActiveIndex];
  }
  function moveMenuHighlight(delta) {
    if (menuButtons.length === 0) {
      return;
    }
    const step = delta >= 0 ? 1 : -1;
    let index = menuActiveIndex;
    for (let guard = 0; guard < menuButtons.length; guard += 1) {
      index = (index + step + menuButtons.length) % menuButtons.length;
      if (index === menuActiveIndex) {
        break;
      }
      const btn = menuButtons[index];
      if (btn && !btn.disabled) {
        menuActiveIndex = index;
        if (typeof btn.focus === 'function') {
          btn.focus();
        }
        return;
      }
    }
  }
  function highlightFirstEnabled() {
    for (let i = 0; i < menuButtons.length; i += 1) {
      if (menuButtons[i] && !menuButtons[i].disabled) {
        menuActiveIndex = i;
        if (typeof menuButtons[i].focus === 'function') {
          menuButtons[i].focus();
        }
        return;
      }
    }
    menuActiveIndex = -1;
  }
  function onMenuKeyDown(event) {
    if (!event) {
      return;
    }
    const key = event.key;
    if (key === 'Escape') {
      if (typeof event.preventDefault === 'function') {
        event.preventDefault();
      }
      closeContextMenu();
      return;
    }
    if (key === 'ArrowDown' || key === 'ArrowUp') {
      if (typeof event.preventDefault === 'function') {
        event.preventDefault();
      }
      moveMenuHighlight(key === 'ArrowDown' ? 1 : -1);
      return;
    }
    if (key === 'Enter') {
      const btn = activeMenuButton();
      if (btn && !btn.disabled) {
        if (typeof event.preventDefault === 'function') {
          event.preventDefault();
        }
        dispatchContextAction(btn);
      }
    }
  }
  async function writeCopyText(text) {
    lastCopyText = text;
    let result;
    try {
      result = await copyText(text);
    } catch (err) {
      result = { ok: false, via: 'none', reason: err && err.message ? err.message : String(err) };
    }
    if (result && result.ok) {
      showToast(t('toast.copied'), 'success');
      return true;
    }
    const reason = result && result.reason ? result.reason : t('toast.copyFailedUnknown');
    showToast(t('toast.copyFailed', { reason: reason }), 'error');
    return false;
  }
  function dispatchContextAction(btn) {
    const action =
      btn && typeof btn.getAttribute === 'function' ? btn.getAttribute('data-action') : null;
    closeContextMenu();
    let pendingCopy = null;
    if (action === CTX_ACTION.COPY_REQUEST_RESPONSE) {
      pendingCopy = runCurrentCopy(MODE_A);
    } else if (action === CTX_ACTION.COPY_SELECTED) {
      pendingCopy = copySelection(MODE_A);
    }
    if (pendingCopy && typeof pendingCopy.catch === 'function') {
      pendingCopy.catch(reportAsyncCopyError);
    }
  }
  function onMenuItemClick(event) {
    if (event) {
      if (typeof event.preventDefault === 'function') {
        event.preventDefault();
      }
      if (typeof event.stopPropagation === 'function') {
        event.stopPropagation();
      }
    }
    const btn = event && event.currentTarget ? event.currentTarget : null;
    if (btn) {
      dispatchContextAction(btn);
    }
  }
  function renderMenuItems(menu, items) {
    clearMenuChildren(menu);
    menuButtons = [];
    for (let i = 0; i < items.length; i += 1) {
      const item = items[i];
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'context-menu__item';
      btn.id = item.id;
      btn.disabled = !item.enabled;
      if (typeof btn.setAttribute === 'function') {
        btn.setAttribute('role', 'menuitem');
        btn.setAttribute('data-action', item.action);
      }
      btn.textContent = t(item.i18nKey, item.vars || undefined);
      btn.addEventListener('click', onMenuItemClick);
      menu.appendChild(btn);
      menuButtons.push(btn);
    }
  }
  function openMenuAt(event) {
    const menu = els.contextMenu;
    if (!menu) {
      return;
    }
    const items = createMenuModel({
      hasSelection: getSelected() !== null,
      count: multi.count(),
    });
    renderMenuItems(menu, items);
    menu.hidden = false;
    const rect = viewportSize();
    const pos = clampPosition({
      x: event ? event.clientX : 0,
      y: event ? event.clientY : 0,
      w: Number(menu.offsetWidth) || 0,
      h: Number(menu.offsetHeight) || 0,
      vw: rect.w,
      vh: rect.h,
    });
    menu.style.left = pos.left + 'px';
    menu.style.top = pos.top + 'px';
    highlightFirstEnabled();
    attachMenuListeners();
  }
  function onContextMenu(event) {
    if (!event) {
      return;
    }
    if (typeof event.preventDefault === 'function') {
      event.preventDefault();
    }
    const rowId = resolveRowId(event, els.listBody);
    if (rowId === null) {
      return;
    }
    const target = event.target;
    const row = target && typeof target.closest === 'function' ? target.closest('.row') : null;
    let index = row ? Number(row.getAttribute('data-index')) : NaN;
    if (!Number.isInteger(index) || index < 0) {
      index = multi.ids().indexOf(rowId);
    }
    if (Number.isInteger(index) && index >= 0) {
      if (!multi.has(rowId)) {
        multi.selectAt(index);
      }
    }
    openMenuAt(event);
  }
  function wireContextMenu() {
    if (els.listBody) {
      els.listBody.addEventListener('contextmenu', onContextMenu);
    }
    const menu = els.contextMenu;
    if (menu && typeof menu.addEventListener === 'function') {
      menu.addEventListener('mousedown', function onMenuMouseDown(event) {
        if (event && typeof event.stopPropagation === 'function') {
          event.stopPropagation();
        }
      });
      menu.addEventListener('click', function onMenuContainerClick(event) {
        if (event && typeof event.stopPropagation === 'function') {
          event.stopPropagation();
        }
      });
      menu.addEventListener('contextmenu', function onMenuContainerContextMenu(event) {
        if (event && typeof event.preventDefault === 'function') {
          event.preventDefault();
        }
        if (event && typeof event.stopPropagation === 'function') {
          event.stopPropagation();
        }
      });
    }
  }
  openContextMenuImpl = onContextMenu;
  wireContextMenu();
  function resolveDetailText(id) {
    const record = store.get(id);
    return record ? buildDetailText(record, resolveResponseBodyText) : '';
  }
  function onDetailClose() {
    if (els.list && typeof els.list.focus === 'function') {
      els.list.focus();
    }
  }
  detailView = createDetailView({
    container: els.detailPane,
    body: els.detailBody,
    resolveText: resolveDetailText,
    onClose: onDetailClose,
  });
  function closeDetailPane() {
    return detailView ? detailView.close() : false;
  }
  function openDetailRecord(id) {
    if (id === undefined || id === null || !detailView) {
      return false;
    }
    if (!store.get(id)) {
      return false;
    }
    const opened = detailView.open(id);
    if (opened && els.detailClose && typeof els.detailClose.focus === 'function') {
      els.detailClose.focus();
    }
    return opened;
  }
  function onRowDblClick(event) {
    if (!event) {
      return;
    }
    const rowId = resolveRowId(event, els.listBody);
    if (rowId === null) {
      return;
    }
    openDetailRecord(rowId);
  }
  function onDetailKeyDown(event) {
    if (!event || event.key !== 'Escape') {
      return;
    }
    if (detailView && detailView.isOpen()) {
      if (typeof event.preventDefault === 'function') {
        event.preventDefault();
      }
      closeDetailPane();
    }
  }
  function onDetailPaneClick(event) {
    const target = event ? event.target : null;
    if (!target || typeof target.closest !== 'function') {
      return;
    }
    if (target.closest('.detail-pane__surface')) {
      return;
    }
    closeDetailPane();
  }
  async function runDetailCopy() {
    const text = buildCurrentCopy(MODE_A);
    if (text === null) {
      showToast(t('copy.hintSelect'), 'error');
      return;
    }
    await writeCopyText(text);
  }
  function onDetailCopyClick(event) {
    if (event) {
      if (typeof event.preventDefault === 'function') {
        event.preventDefault();
      }
      if (typeof event.stopPropagation === 'function') {
        event.stopPropagation();
      }
    }
    const pendingCopy = runDetailCopy();
    if (pendingCopy && typeof pendingCopy.catch === 'function') {
      pendingCopy.catch(reportAsyncCopyError);
    }
  }
  function ensureDetailCopyButton() {
    const pane = els.detailPane;
    const header = pane && typeof pane.querySelector === 'function'
      ? pane.querySelector('.detail-pane__header')
      : null;
    if (!header) {
      return null;
    }
    let btn = header.querySelector('#' + DETAIL_COPY_BTN_ID);
    if (btn) {
      return btn;
    }
    btn = document.createElement('button');
    btn.type = 'button';
    btn.id = DETAIL_COPY_BTN_ID;
    btn.className = 'btn detail-pane__copy';
    btn.setAttribute('data-i18n', 'detail.copyButton');
    btn.textContent = t('detail.copyButton');
    btn.addEventListener('click', onDetailCopyClick);
    if (els.detailClose && els.detailClose.parentNode === header) {
      header.insertBefore(btn, els.detailClose);
    } else {
      header.appendChild(btn);
    }
    return btn;
  }
  function wireDetail() {
    if (els.listBody) {
      els.listBody.addEventListener('dblclick', onRowDblClick);
    }
    if (els.detailClose) {
      els.detailClose.addEventListener('click', closeDetailPane);
    }
    if (els.detailPane) {
      els.detailPane.addEventListener('click', onDetailPaneClick);
    }
    if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {
      document.addEventListener('keydown', onDetailKeyDown);
    }
    ensureDetailCopyButton();
  }
  openDetailImpl = openDetailRecord;
  closeDetailImpl = closeDetailPane;
  wireDetail();
  refreshView();
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init, { once: true });
} else {
  init();
}
export default {
  els,
  applyI18n,
  showToast,
  setEmptyState,
  getCopyMode,
  getSelected,
  buildCurrentCopy,
  getLastCopyText,
  getSelectedIds,
  copySelection,
  openContextMenu,
  openDetail,
  closeDetail,
};
function wirePrivacyLink() {
  const link = els.privacyLink;
  if (!link) {
    return;
  }
  link.addEventListener('click', function onPrivacyLinkClick(event) {
    if (event && typeof event.preventDefault === 'function') {
      event.preventDefault();
    }
    const target = link.getAttribute('href') || 'privacy.html';
    try {
      window.open(target, '_blank');
    } catch (err) {
      if (typeof console !== 'undefined' && typeof console.warn === 'function') {
        console.warn(
          '[E_PRIVACY_OPEN_FAILED] ' + (err && err.message ? err.message : String(err))
        );
      }
    }
  });
}
wirePrivacyLink();