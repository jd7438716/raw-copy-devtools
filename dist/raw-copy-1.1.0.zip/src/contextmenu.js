export const E_CTX_NO_TARGET = 'E_CTX_NO_TARGET';
export const CTX_ACTION = {
  COPY_REQUEST_RESPONSE: 'copyRequestResponse',
  COPY_SELECTED: 'copySelected',
};
export const CTX_ITEM_ID = {
  COPY_REQUEST_RESPONSE: 'copy-request-response',
  COPY_SELECTED: 'copy-selected',
};
const ROW_SELECTOR = '.row';
const INT_RE = /^-?\d+$/;
function toRecordId(raw) {
  if (INT_RE.test(raw)) {
    const n = Number(raw);
    if (Number.isSafeInteger(n) && String(n) === raw) {
      return n;
    }
  }
  return raw;
}
export function resolveRowId(event, listBodyEl) {
  if (!event || typeof event !== 'object') {
    return null;
  }
  const target = event.target;
  if (!target || typeof target.closest !== 'function') {
    return null;
  }
  let row;
  try {
    row = target.closest(ROW_SELECTOR);
  } catch (_err) {
    return null;
  }
  if (!row) {
    return null;
  }
  if (listBodyEl && typeof listBodyEl.contains === 'function') {
    let contained = true;
    try {
      contained = listBodyEl.contains(row);
    } catch (_err) {
      contained = true;
    }
    if (!contained) {
      return null;
    }
  }
  let raw = null;
  if (typeof row.getAttribute === 'function') {
    raw = row.getAttribute('data-id');
  } else if (row.dataset && row.dataset.id !== undefined) {
    raw = row.dataset.id;
  }
  if (raw === null || raw === undefined) {
    return null;
  }
  const text = String(raw);
  if (text === '') {
    return null;
  }
  return toRecordId(text);
}
function makeItem(id, i18nKey, action, enabled, options) {
  const extra = options && typeof options === 'object' ? options : {};
  return {
    id,
    i18nKey,
    enabled: Boolean(enabled),
    action,
    vars: extra.vars && typeof extra.vars === 'object' ? extra.vars : null,
  };
}
export function createMenuModel(context) {
  const ctx = context && typeof context === 'object' ? context : {};
  const hasSelection = Boolean(ctx.hasSelection);
  const rawCount = Number(ctx.count);
  const count = Number.isFinite(rawCount) && rawCount > 0 ? Math.floor(rawCount) : 0;
  const items = [];
  items.push(
    makeItem(
      CTX_ITEM_ID.COPY_REQUEST_RESPONSE,
      'contextmenu.copyRequestResponse',
      CTX_ACTION.COPY_REQUEST_RESPONSE,
      hasSelection,
    ),
  );
  if (count >= 2) {
    items.push(
      makeItem(
        CTX_ITEM_ID.COPY_SELECTED,
        'contextmenu.copySelected',
        CTX_ACTION.COPY_SELECTED,
        true,
        { vars: { count } },
      ),
    );
  }
  return items;
}
function finite(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}
export function clampPosition(rect) {
  const r = rect && typeof rect === 'object' ? rect : {};
  const x = finite(r.x);
  const y = finite(r.y);
  const w = Math.max(0, finite(r.w));
  const h = Math.max(0, finite(r.h));
  const vw = Math.max(0, finite(r.vw));
  const vh = Math.max(0, finite(r.vh));
  const maxLeft = Math.max(0, vw - w);
  const maxTop = Math.max(0, vh - h);
  return {
    left: Math.min(Math.max(x, 0), maxLeft),
    top: Math.min(Math.max(y, 0), maxTop),
  };
}
export default { E_CTX_NO_TARGET, CTX_ACTION, CTX_ITEM_ID, resolveRowId, createMenuModel, clampPosition };