export const DEFAULT_TOAST_MS = 2400;
const TOAST_KINDS = ['info', 'success', 'error'];
const toastTimers = new WeakMap();
function describeError(err) {
  if (err && typeof err.message === 'string' && err.message.length > 0) {
    return err.message;
  }
  if (typeof err === 'string' && err.length > 0) {
    return err;
  }
  return 'unknown error';
}
function resolveNavigator(deps) {
  if (deps && deps.navigator) {
    return deps.navigator;
  }
  if (typeof navigator !== 'undefined') {
    return navigator;
  }
  return null;
}
function resolveDocument(deps) {
  if (deps && deps.document) {
    return deps.document;
  }
  if (typeof document !== 'undefined') {
    return document;
  }
  return null;
}
async function copyViaAsyncApi(text, nav) {
  if (!nav || !nav.clipboard || typeof nav.clipboard.writeText !== 'function') {
    return { ok: false, reason: 'Clipboard API unavailable' };
  }
  try {
    await nav.clipboard.writeText(text);
    return { ok: true };
  } catch (err) {
    return { ok: false, reason: describeError(err) };
  }
}
function removeTextarea(textarea) {
  if (!textarea) {
    return;
  }
  if (typeof textarea.remove === 'function') {
    textarea.remove();
    return;
  }
  const parent = textarea.parentNode;
  if (parent && typeof parent.removeChild === 'function') {
    parent.removeChild(textarea);
  }
}
function copyViaExecCommand(text, doc) {
  if (!doc || typeof doc.execCommand !== 'function') {
    return { ok: false, reason: 'execCommand unavailable' };
  }
  let textarea = null;
  let host = null;
  try {
    if (typeof doc.createElement === 'function') {
      textarea = doc.createElement('textarea');
      textarea.value = text;
      if (typeof textarea.setAttribute === 'function') {
        textarea.setAttribute('readonly', '');
      }
      if (textarea.style) {
        textarea.style.position = 'fixed';
        textarea.style.top = '-9999px';
        textarea.style.left = '-9999px';
        textarea.style.opacity = '0';
      }
      host = doc.body || doc.documentElement || null;
      if (host && typeof host.appendChild === 'function') {
        host.appendChild(textarea);
      }
      if (typeof textarea.focus === 'function') {
        textarea.focus();
      }
      if (typeof textarea.select === 'function') {
        textarea.select();
      }
      if (typeof textarea.setSelectionRange === 'function') {
        textarea.setSelectionRange(0, text.length);
      }
    }
    const ok = doc.execCommand('copy');
    return ok ? { ok: true } : { ok: false, reason: 'execCommand returned false' };
  } catch (err) {
    return { ok: false, reason: describeError(err) };
  } finally {
    removeTextarea(textarea);
  }
}
export async function copyText(text, deps = {}) {
  const value = typeof text === 'string' ? text : text === null || text === undefined ? '' : String(text);
  const nav = resolveNavigator(deps);
  const doc = resolveDocument(deps);
  const primary = await copyViaAsyncApi(value, nav);
  if (primary.ok) {
    return { ok: true, via: 'async' };
  }
  const fallback = copyViaExecCommand(value, doc);
  if (fallback.ok) {
    return { ok: true, via: 'execCommand' };
  }
  return {
    ok: false,
    via: 'none',
    reason: fallback.reason || primary.reason || 'copy failed',
  };
}
function normalizeKind(kind) {
  return TOAST_KINDS.indexOf(kind) !== -1 ? kind : 'info';
}
function resolveToastEl(deps) {
  if (deps && deps.el) {
    return deps.el;
  }
  const doc = resolveDocument(deps);
  if (doc && typeof doc.querySelector === 'function') {
    return doc.querySelector('#toast');
  }
  return null;
}
function applyToast(el, message, kind) {
  if (!el) {
    return false;
  }
  el.textContent = typeof message === 'string' ? message : '';
  if (el.classList && typeof el.classList.remove === 'function') {
    el.classList.remove('toast--info', 'toast--success', 'toast--error');
  }
  if (el.classList && typeof el.classList.add === 'function') {
    el.classList.add('toast--' + normalizeKind(kind));
  }
  if (typeof el.setAttribute === 'function') {
    el.setAttribute('data-visible', 'true');
  }
  return true;
}
function resolveTimers(deps) {
  const setTimer =
    deps && typeof deps.setTimeout === 'function'
      ? deps.setTimeout
      : typeof setTimeout !== 'undefined'
        ? setTimeout
        : null;
  const clearTimer =
    deps && typeof deps.clearTimeout === 'function'
      ? deps.clearTimeout
      : typeof clearTimeout !== 'undefined'
        ? clearTimeout
        : null;
  return { setTimer, clearTimer };
}
export function showToast(message, kind = 'info', deps = {}) {
  const el = resolveToastEl(deps);
  if (!applyToast(el, message, kind)) {
    return false;
  }
  const { setTimer, clearTimer } = resolveTimers(deps);
  const duration =
    deps && typeof deps.durationMs === 'number' ? deps.durationMs : DEFAULT_TOAST_MS;
  const existing = toastTimers.get(el);
  if (existing !== undefined && clearTimer) {
    clearTimer(existing);
    toastTimers.delete(el);
  }
  if (duration > 0 && setTimer) {
    const id = setTimer(function hideToast() {
      if (typeof el.setAttribute === 'function') {
        el.setAttribute('data-visible', 'false');
      }
      toastTimers.delete(el);
    }, duration);
    toastTimers.set(el, id);
  }
  return true;
}
export function createToast(el, options = {}) {
  const { setTimer, clearTimer } = resolveTimers(options);
  const duration =
    typeof options.durationMs === 'number' ? options.durationMs : DEFAULT_TOAST_MS;
  let timer = null;
  return function toast(message, kind = 'info') {
    if (!applyToast(el, message, kind)) {
      return false;
    }
    if (timer !== null && clearTimer) {
      clearTimer(timer);
      timer = null;
    }
    if (duration > 0 && setTimer) {
      timer = setTimer(function hideToast() {
        if (el && typeof el.setAttribute === 'function') {
          el.setAttribute('data-visible', 'false');
        }
        timer = null;
      }, duration);
    }
    return true;
  };
}
export default { copyText, showToast, createToast, DEFAULT_TOAST_MS };