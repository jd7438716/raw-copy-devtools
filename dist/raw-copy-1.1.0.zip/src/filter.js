function asArray(value) {
  return Array.isArray(value) ? value : [];
}
function asCriteriaText(value) {
  if (typeof value === 'string') {
    return value;
  }
  if (typeof value === 'number' && Number.isFinite(value)) {
    return String(value);
  }
  return '';
}
function recordUrl(record) {
  return record && typeof record.url === 'string' ? record.url : '';
}
function recordMethod(record) {
  return record && typeof record.method === 'string' ? record.method : '';
}
function recordResourceType(record) {
  return record && typeof record.resourceType === 'string' ? record.resourceType : '';
}
function recordStatusNumber(record) {
  const value = record ? record.status : undefined;
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value;
  }
  if (typeof value === 'string' && value.trim() !== '') {
    const n = Number(value);
    return Number.isFinite(n) ? n : NaN;
  }
  return NaN;
}
function matchQuery(url, criteria) {
  const query = asCriteriaText(criteria).trim();
  if (query === '') {
    return true;
  }
  return url.toLowerCase().indexOf(query.toLowerCase()) !== -1;
}
function matchMethod(method, criteria) {
  const wanted = asCriteriaText(criteria).trim();
  if (wanted === '') {
    return true;
  }
  return method.trim().toLowerCase() === wanted.toLowerCase();
}
function matchStatus(status, criteria) {
  const wanted = asCriteriaText(criteria).trim();
  if (wanted === '') {
    return true;
  }
  if (!Number.isFinite(status)) {
    return false;
  }
  const range = wanted.match(/^([1-5])[xX]{1,2}$/);
  if (range) {
    const base = Number(range[1]) * 100;
    return status >= base && status <= base + 99;
  }
  const exact = Number(wanted);
  if (Number.isFinite(exact)) {
    return status === exact;
  }
  return false;
}
function matchResourceType(resourceType, criteria) {
  const wanted = asCriteriaText(criteria).trim();
  if (wanted === '') {
    return true;
  }
  return resourceType.trim().toLowerCase() === wanted.toLowerCase();
}
function isInactive(criteria) {
  return asCriteriaText(criteria).trim() === '';
}
export function applyFilter(records, criteria) {
  const list = asArray(records);
  const c = criteria && typeof criteria === 'object' ? criteria : {};
  if (
    isInactive(c.query) &&
    isInactive(c.method) &&
    isInactive(c.status) &&
    isInactive(c.resourceType)
  ) {
    return list.slice();
  }
  const out = [];
  for (let i = 0; i < list.length; i += 1) {
    const record = list[i];
    if (!matchQuery(recordUrl(record), c.query)) {
      continue;
    }
    if (!matchMethod(recordMethod(record), c.method)) {
      continue;
    }
    if (!matchStatus(recordStatusNumber(record), c.status)) {
      continue;
    }
    if (!matchResourceType(recordResourceType(record), c.resourceType)) {
      continue;
    }
    out.push(record);
  }
  return out;
}
function sortStrings(set) {
  return Array.from(set).sort(function compare(a, b) {
    const la = a.toLowerCase();
    const lb = b.toLowerCase();
    if (la < lb) {
      return -1;
    }
    if (la > lb) {
      return 1;
    }
    if (a < b) {
      return -1;
    }
    if (a > b) {
      return 1;
    }
    return 0;
  });
}
function sortStatuses(set) {
  return Array.from(set).sort(function compare(a, b) {
    return Number(a) - Number(b);
  });
}
export function collectOptions(records) {
  const list = asArray(records);
  const methods = new Set();
  const statuses = new Set();
  const resourceTypes = new Set();
  for (let i = 0; i < list.length; i += 1) {
    const record = list[i];
    const method = recordMethod(record).trim();
    if (method !== '') {
      methods.add(method.toUpperCase());
    }
    const status = recordStatusNumber(record);
    if (Number.isFinite(status) && status > 0) {
      statuses.add(String(status));
    }
    const resourceType = recordResourceType(record).trim();
    if (resourceType !== '') {
      resourceTypes.add(resourceType);
    }
  }
  return {
    methods: sortStrings(methods),
    statuses: sortStatuses(statuses),
    resourceTypes: sortStrings(resourceTypes),
  };
}
export default { applyFilter, collectOptions };