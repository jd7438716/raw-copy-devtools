import { createSelection } from './selection.js';
function toIdList(value) {
  return Array.isArray(value) ? value.slice() : [];
}
function isValidId(id) {
  return id !== undefined && id !== null;
}
export function createMultiSelection(options = {}) {
  const opts = options && typeof options === 'object' ? options : {};
  const onChange = typeof opts.onChange === 'function' ? opts.onChange : null;
  const primary = createSelection({ ids: toIdList(opts.ids) });
  const selected = new Set();
  let anchorId = null;
  function idAt(index) {
    const i = Number(index);
    if (!Number.isInteger(i) || i < 0) {
      return { ok: false };
    }
    const ids = primary.ids();
    if (i >= ids.length) {
      return { ok: false };
    }
    const id = ids[i];
    if (!isValidId(id)) {
      return { ok: false };
    }
    return { ok: true, id, index: i, ids };
  }
  function indexOfList(id) {
    return primary.ids().indexOf(id);
  }
  function selectedIds() {
    const ids = primary.ids();
    const out = [];
    const seen = new Set();
    for (let i = 0; i < ids.length; i += 1) {
      const id = ids[i];
      if (!isValidId(id) || seen.has(id)) {
        continue;
      }
      if (selected.has(id)) {
        seen.add(id);
        out.push(id);
      }
    }
    return out;
  }
  function firstSelectedId() {
    const arr = selectedIds();
    return arr.length > 0 ? arr[0] : null;
  }
  function syncPrimaryToSet(preferredId) {
    if (selected.size === 0) {
      return;
    }
    if (
      isValidId(preferredId) &&
      selected.has(preferredId) &&
      indexOfList(preferredId) !== -1
    ) {
      primary.selectId(preferredId);
      return;
    }
    const cur = primary.current();
    if (cur !== null && selected.has(cur)) {
      return;
    }
    const first = firstSelectedId();
    if (first !== null) {
      primary.selectId(first);
    }
  }
  function emit() {
    if (!onChange) {
      return;
    }
    try {
      onChange(primary.current(), primary.index(), selectedIds());
    } catch (_err) {
    }
  }
  function selectAt(index) {
    const hit = idAt(index);
    if (!hit.ok) {
      return false;
    }
    selected.clear();
    selected.add(hit.id);
    anchorId = hit.id;
    primary.selectAt(hit.index);
    emit();
    return true;
  }
  function toggleAt(index) {
    const hit = idAt(index);
    if (!hit.ok) {
      return false;
    }
    anchorId = hit.id;
    if (selected.has(hit.id)) {
      selected.delete(hit.id);
      if (primary.current() === hit.id) {
        const first = firstSelectedId();
        if (first === null) {
          primary.reset();
        } else {
          primary.selectId(first);
        }
      }
    } else {
      selected.add(hit.id);
      primary.selectId(hit.id);
    }
    emit();
    return true;
  }
  function rangeTo(index) {
    const hit = idAt(index);
    if (!hit.ok) {
      return false;
    }
    const ids = hit.ids;
    let base = anchorId;
    if (!isValidId(base) || ids.indexOf(base) === -1) {
      const cur = primary.current();
      base = isValidId(cur) && ids.indexOf(cur) !== -1 ? cur : null;
    }
    if (base === null) {
      return selectAt(hit.index);
    }
    const a = ids.indexOf(base);
    const lo = Math.min(a, hit.index);
    const hi = Math.max(a, hit.index);
    selected.clear();
    for (let i = lo; i <= hi; i += 1) {
      const id = ids[i];
      if (isValidId(id)) {
        selected.add(id);
      }
    }
    primary.selectId(hit.id);
    emit();
    return true;
  }
  function extendTo(index) {
    const hit = idAt(index);
    if (!hit.ok) {
      return false;
    }
    const ids = hit.ids;
    let base = anchorId;
    if (!isValidId(base) || ids.indexOf(base) === -1) {
      const cur = primary.current();
      base = isValidId(cur) && ids.indexOf(cur) !== -1 ? cur : null;
    }
    if (base === null) {
      return selectAt(hit.index);
    }
    const a = ids.indexOf(base);
    const lo = Math.min(a, hit.index);
    const hi = Math.max(a, hit.index);
    for (let i = lo; i <= hi; i += 1) {
      const id = ids[i];
      if (isValidId(id)) {
        selected.add(id);
      }
    }
    primary.selectId(hit.id);
    emit();
    return true;
  }
  function selectAll() {
    const ids = primary.ids();
    let changed = false;
    for (let i = 0; i < ids.length; i += 1) {
      const id = ids[i];
      if (!isValidId(id)) {
        continue;
      }
      if (!selected.has(id)) {
        selected.add(id);
        changed = true;
      }
    }
    const cur = primary.current();
    if (selected.size > 0 && (cur === null || !selected.has(cur))) {
      const first = firstSelectedId();
      if (first !== null) {
        primary.selectId(first);
        changed = true;
      }
    }
    if (changed) {
      emit();
    }
    return changed;
  }
  function clear() {
    const changed =
      selected.size > 0 || anchorId !== null || primary.current() !== null;
    selected.clear();
    anchorId = null;
    primary.reset();
    if (changed) {
      emit();
    }
    return changed;
  }
  function move(delta) {
    const hadSet = selected.size > 0 || anchorId !== null;
    selected.clear();
    anchorId = null;
    const moved = primary.move(delta);
    if (moved || hadSet) {
      emit();
    }
    return moved || hadSet;
  }
  function current() {
    return primary.current();
  }
  function has(id) {
    return selected.has(id);
  }
  function count() {
    return selected.size;
  }
  function setIds(next) {
    const beforeSize = selected.size;
    const beforeAnchor = anchorId;
    const beforePrimary = primary.current();
    const nextIds = toIdList(next);
    const lookup = new Set();
    for (let i = 0; i < nextIds.length; i += 1) {
      if (isValidId(nextIds[i])) {
        lookup.add(nextIds[i]);
      }
    }
    for (const id of Array.from(selected)) {
      if (!lookup.has(id)) {
        selected.delete(id);
      }
    }
    if (anchorId !== null && !lookup.has(anchorId)) {
      anchorId = null;
    }
    primary.setIds(nextIds);
    if (selected.size > 0) {
      syncPrimaryToSet();
    }
    const changed =
      selected.size !== beforeSize ||
      anchorId !== beforeAnchor ||
      primary.current() !== beforePrimary;
    if (changed) {
      emit();
    }
    return selectedIds();
  }
  function onEvict(id) {
    const beforeSize = selected.size;
    const beforeAnchor = anchorId;
    const beforePrimary = primary.current();
    primary.onEvict(id);
    selected.delete(id);
    if (anchorId === id) {
      anchorId = null;
    }
    if (selected.size > 0) {
      syncPrimaryToSet();
    }
    const changed =
      selected.size !== beforeSize ||
      anchorId !== beforeAnchor ||
      primary.current() !== beforePrimary;
    if (changed) {
      emit();
    }
    return changed;
  }
  function ids() {
    return primary.ids();
  }
  function size() {
    return primary.size();
  }
  return {
    selectAt,
    toggleAt,
    rangeTo,
    extendTo,
    selectAll,
    clear,
    move,
    current,
    selectedIds,
    has,
    count,
    setIds,
    onEvict,
    ids,
    size,
  };
}
export default { createMultiSelection };