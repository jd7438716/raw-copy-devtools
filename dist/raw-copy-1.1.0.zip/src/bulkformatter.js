import { buildCopyText, MODE_A } from './formatter.js';
function marker(i, total) {
  return '===== #' + i + '/' + total + ' =====';
}
function buildBlock(record, mode, resolveBody) {
  if (typeof resolveBody === 'function') {
    return buildCopyText(record, mode, { responseBody: resolveBody(record) });
  }
  return buildCopyText(record, mode);
}
export function joinBlocks(blocks, N) {
  const list = Array.isArray(blocks) ? blocks : [];
  if (list.length === 0) {
    return '';
  }
  const total = Number.isFinite(N) && N > 0 ? Math.trunc(N) : list.length;
  if (total <= 1) {
    return list[0];
  }
  const marked = [];
  for (let i = 0; i < list.length; i += 1) {
    marked.push(marker(i + 1, total) + '\n' + list[i]);
  }
  return marked.join('\n\n');
}
export function buildBulkCopyText(records, mode = MODE_A, resolveBody) {
  const list = Array.isArray(records) ? records : [];
  const total = list.length;
  if (total === 0) {
    return '';
  }
  const blocks = [];
  for (let i = 0; i < total; i += 1) {
    blocks.push(buildBlock(list[i], mode, resolveBody));
  }
  if (total === 1) {
    return blocks[0];
  }
  return joinBlocks(blocks, total);
}
export default { joinBlocks, buildBulkCopyText };