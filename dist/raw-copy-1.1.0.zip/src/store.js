export const DEFAULT_CAPACITY = 1000;
export const DEFAULT_MAX_BYTES = 64 * 1024 * 1024;
export const DEFAULT_PENDING_TIMEOUT_MS = 3000;
const RECORD_BASE_BYTES = 128;
function toRecord(value) {
  return value && typeof value === 'object' ? value : {};
}
function normalizeCapacity(capacity) {
  const n = Number(capacity);
  if (!Number.isFinite(n) || n < 1) {
    return DEFAULT_CAPACITY;
  }
  return Math.floor(n);
}
function normalizeMaxBytes(maxBytes) {
  const n = Number(maxBytes);
  if (!Number.isFinite(n) || n <= 0) {
    return DEFAULT_MAX_BYTES;
  }
  return Math.floor(n);
}
function normalizeTimeout(timeoutMs) {
  const n = Number(timeoutMs);
  if (!Number.isFinite(n) || n <= 0) {
    return DEFAULT_PENDING_TIMEOUT_MS;
  }
  return Math.floor(n);
}
function utf8ByteLength(text) {
  if (typeof text !== 'string' || text.length === 0) {
    return 0;
  }
  if (typeof TextEncoder === 'function') {
    return new TextEncoder().encode(text).length;
  }
  let bytes = 0;
  for (let i = 0; i < text.length; i += 1) {
    const code = text.charCodeAt(i);
    if (code < 0x80) {
      bytes += 1;
    } else if (code < 0x800) {
      bytes += 2;
    } else if (code >= 0xd800 && code <= 0xdbff) {
      bytes += 4;
      i += 1;
    } else {
      bytes += 3;
    }
  }
  return bytes;
}
function estimateRecordBytes(record) {
  if (!record || typeof record !== 'object') {
    return RECORD_BASE_BYTES;
  }
  let bytes = RECORD_BASE_BYTES;
  if (typeof record.requestBody === 'string') {
    bytes += utf8ByteLength(record.requestBody);
  }
  if (typeof record.url === 'string') {
    bytes += record.url.length;
  }
  const rc = record.responseContent;
  if (rc && typeof rc === 'object') {
    if (typeof rc.text === 'string') {
      bytes += utf8ByteLength(rc.text);
    }
    if (typeof rc.mimeType === 'string') {
      bytes += rc.mimeType.length;
    }
  }
  bytes += headersBytes(record.requestHeaders);
  bytes += headersBytes(record.responseHeaders);
  return bytes;
}
function headersBytes(headers) {
  if (!Array.isArray(headers)) {
    return 0;
  }
  let bytes = 0;
  for (let i = 0; i < headers.length; i += 1) {
    const h = headers[i];
    if (!h || typeof h !== 'object') {
      continue;
    }
    if (typeof h.name === 'string') {
      bytes += h.name.length;
    }
    if (typeof h.value === 'string') {
      bytes += h.value.length;
    }
  }
  return bytes;
}
function assignId(record, id) {
  try {
    record.id = id;
    return record.id === id;
  } catch (_err) {
    return false;
  }
}
export function createStore({
  capacity = DEFAULT_CAPACITY,
  maxBytes = DEFAULT_MAX_BYTES,
} = {}) {
  const cap = normalizeCapacity(capacity);
  const budget = normalizeMaxBytes(maxBytes);
  const buf = new Array(cap);
  const index = new Map();
  const sizes = new Map();
  const pending = new Map();
  const subscribers = new Set();
  let head = 0;
  let count = 0;
  let nextId = 1;
  let totalBytes = 0;
  function isUsableId(value) {
    return typeof value === 'number' && Number.isFinite(value) && !index.has(value);
  }
  function notify(event) {
    if (subscribers.size === 0) {
      return;
    }
    const snapshot = Array.from(subscribers);
    for (let i = 0; i < snapshot.length; i += 1) {
      try {
        snapshot[i](event);
      } catch (_err) {
      }
    }
  }
  function detachRecord(id) {
    const bytes = sizes.get(id) || 0;
    index.delete(id);
    sizes.delete(id);
    totalBytes -= bytes;
    if (totalBytes < 0) {
      totalBytes = 0;
    }
    rejectPending(id, 'evicted');
    return bytes;
  }
  function evictOldestForBudget() {
    if (count === 0) {
      return null;
    }
    const start = (head - count + cap) % cap;
    const oldest = buf[start];
    buf[start] = undefined;
    count -= 1;
    if (!oldest || typeof oldest.id !== 'number') {
      return null;
    }
    detachRecord(oldest.id);
    return oldest.id;
  }
  function enforceBudget() {
    const evicted = [];
    while (totalBytes > budget && count > 0) {
      const id = evictOldestForBudget();
      if (id === null) {
        break;
      }
      evicted.push(id);
    }
    for (let i = 0; i < evicted.length; i += 1) {
      notify({ type: 'evict', id: evicted[i], reason: 'maxBytes' });
    }
    return evicted;
  }
  function markPending(id) {
    if (typeof id !== 'number' || !Number.isFinite(id)) {
      return false;
    }
    const entry = { settled: false, promise: null, resolve: null, reject: null };
    entry.promise = new Promise(function executor(resolve, reject) {
      entry.resolve = resolve;
      entry.reject = reject;
    });
    entry.promise.catch(function noop() {});
    pending.set(id, entry);
    return true;
  }
  function isPending(id) {
    const entry = pending.get(id);
    return !!(entry && !entry.settled);
  }
  function resolvePending(id, value) {
    const entry = pending.get(id);
    if (!entry || entry.settled) {
      return false;
    }
    entry.settled = true;
    pending.delete(id);
    entry.resolve(value);
    return true;
  }
  function rejectPending(id, reason) {
    const entry = pending.get(id);
    if (!entry || entry.settled) {
      return false;
    }
    entry.settled = true;
    pending.delete(id);
    const err = reason instanceof Error ? reason : new Error(String(reason === undefined ? 'pending rejected' : reason));
    entry.reject(err);
    return true;
  }
  function rejectAllPending(reason) {
    const ids = Array.from(pending.keys());
    for (let i = 0; i < ids.length; i += 1) {
      rejectPending(ids[i], reason);
    }
  }
  function awaitPending(id, timeoutMs) {
    const entry = pending.get(id);
    if (!entry || entry.settled) {
      return Promise.resolve(true);
    }
    const ms = normalizeTimeout(timeoutMs);
    return new Promise(function executor(resolve, reject) {
      let done = false;
      let timer = null;
      timer = setTimeout(function onTimeout() {
        if (done) {
          return;
        }
        done = true;
        const err = new Error('pending await timeout (' + ms + 'ms)');
        err.code = 'E_PENDING_TIMEOUT';
        reject(err);
      }, ms);
      entry.promise.then(
        function onResolved(value) {
          if (done) {
            return;
          }
          done = true;
          clearTimeout(timer);
          resolve(value);
        },
        function onRejected(err) {
          if (done) {
            return;
          }
          done = true;
          clearTimeout(timer);
          reject(err);
        }
      );
    });
  }
  function add(rec) {
    let record = toRecord(rec);
    let id;
    if (isUsableId(record.id)) {
      id = record.id;
      if (id >= nextId) {
        nextId = id + 1;
      }
    } else {
      id = nextId;
      nextId += 1;
    }
    if (!assignId(record, id)) {
      record = Object.assign({}, record, { id });
    }
    let evicted = null;
    if (count === cap) {
      const oldest = buf[head];
      if (oldest && typeof oldest.id === 'number') {
        evicted = oldest.id;
        detachRecord(evicted);
      }
      buf[head] = record;
      head = (head + 1) % cap;
    } else {
      buf[head] = record;
      head = (head + 1) % cap;
      count += 1;
    }
    index.set(id, record);
    const bytes = estimateRecordBytes(record);
    sizes.set(id, bytes);
    totalBytes += bytes;
    notify({ type: 'add', id, record, evicted });
    enforceBudget();
    return id;
  }
  function get(id) {
    return index.get(id);
  }
  function update(id, patch) {
    const record = index.get(id);
    if (!record) {
      return false;
    }
    const p = patch && typeof patch === 'object' ? patch : {};
    const before = sizes.get(id) || 0;
    totalBytes -= before;
    if (totalBytes < 0) {
      totalBytes = 0;
    }
    try {
      Object.assign(record, p);
    } catch (_err) {
      totalBytes += before;
      return false;
    }
    const after = estimateRecordBytes(record);
    sizes.set(id, after);
    totalBytes += after;
    notify({ type: 'update', id, record, patch: p });
    enforceBudget();
    return true;
  }
  function all() {
    const out = new Array(count);
    const start = (head - count + cap) % cap;
    for (let i = 0; i < count; i += 1) {
      out[i] = buf[(start + i) % cap];
    }
    return out;
  }
  function size() {
    return count;
  }
  function bytesInUse() {
    return totalBytes;
  }
  function clear() {
    for (let i = 0; i < cap; i += 1) {
      buf[i] = undefined;
    }
    index.clear();
    sizes.clear();
    totalBytes = 0;
    head = 0;
    count = 0;
    rejectAllPending('clear');
    notify({ type: 'clear' });
  }
  function subscribe(fn) {
    if (typeof fn !== 'function') {
      return function noop() {};
    }
    subscribers.add(fn);
    return function unsubscribe() {
      subscribers.delete(fn);
    };
  }
  return {
    add,
    get,
    all,
    size,
    update,
    bytesInUse,
    clear,
    markPending,
    isPending,
    resolvePending,
    rejectPending,
    awaitPending,
    subscribe,
  };
}
export default createStore;