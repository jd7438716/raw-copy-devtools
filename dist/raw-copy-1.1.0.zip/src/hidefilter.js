export const HIDDEN_RESOURCE_TYPES = Object.freeze([
  'script',
  'stylesheet',
  'font',
  'image',
  'media',
]);
const HIDDEN_SET = new Set(HIDDEN_RESOURCE_TYPES);
const KEEP_RESOURCE_TYPES = new Set(['xhr', 'fetch', 'websocket', 'eventsource']);
const STATIC_MIME = new Set([
  'text/css',
  'application/javascript',
  'text/javascript',
  'application/x-javascript',
  'application/pdf',
]);
const STATIC_MIME_PREFIXES = ['image/', 'font/', 'audio/', 'video/'];
const STATIC_EXTENSIONS = new Set([
  'js', 'mjs', 'cjs', 'css',
  'woff', 'woff2', 'ttf', 'otf', 'eot',
  'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'avif', 'ico', 'bmp',
  'pdf',
  'mp4', 'webm', 'ogg', 'mp3', 'wav', 'flac', 'm4a', 'm4v', 'mov',
  'vtt',
]);
function asString(value) {
  return typeof value === 'string' ? value : '';
}
function urlPathname(url) {
  const raw = asString(url);
  if (raw === '') {
    return '';
  }
  const noHash = raw.split('#')[0];
  const noQuery = noHash.split('?')[0];
  const m = /^[a-z][a-z0-9+.-]*:\/\/[^/]*(\/[\s\S]*)?$/i.exec(noQuery);
  if (m) {
    return m[1] || '/';
  }
  return noQuery;
}
function urlExtension(url) {
  const path = urlPathname(url);
  const last = path.split('/').pop() || '';
  const dot = last.lastIndexOf('.');
  if (dot <= 0 || dot === last.length - 1) {
    return '';
  }
  return last.slice(dot + 1).toLowerCase();
}
function mimeEssence(record) {
  const content = record && record.responseContent;
  const mime = content && typeof content.mimeType === 'string' ? content.mimeType : '';
  return mime.split(';')[0].trim().toLowerCase();
}
export function isPdf(record) {
  if (mimeEssence(record) === 'application/pdf') {
    return true;
  }
  return urlExtension(record && record.url) === 'pdf';
}
export function isStaticResource(record) {
  if (!record || typeof record !== 'object') {
    return false;
  }
  const resourceType = asString(record.resourceType).trim().toLowerCase();
  if (KEEP_RESOURCE_TYPES.has(resourceType)) {
    return false;
  }
  if (resourceType === 'document') {
    return isPdf(record);
  }
  if (HIDDEN_SET.has(resourceType)) {
    return true;
  }
  if (isPdf(record)) {
    return true;
  }
  const mime = mimeEssence(record);
  if (mime !== '') {
    if (STATIC_MIME.has(mime)) {
      return true;
    }
    for (let i = 0; i < STATIC_MIME_PREFIXES.length; i += 1) {
      if (mime.indexOf(STATIC_MIME_PREFIXES[i]) === 0) {
        return true;
      }
    }
  }
  return STATIC_EXTENSIONS.has(urlExtension(record.url));
}
export function applyHide(records, hideStatic) {
  const list = Array.isArray(records) ? records : [];
  if (!hideStatic) {
    return list.slice();
  }
  const out = [];
  for (let i = 0; i < list.length; i += 1) {
    if (!isStaticResource(list[i])) {
      out.push(list[i]);
    }
  }
  return out;
}
export default { HIDDEN_RESOURCE_TYPES, isStaticResource, applyHide, isPdf };