export const DEFAULT_LANG = 'zh';
export const SUPPORTED_LANGS = ['zh', 'en'];
export const dict = {
  zh: {
    'panel.name': 'Raw Copy',
    'panel.title': '请求原始信息复制',
    'panel.subtitle': '选中单条请求，一键复制完整请求与响应（纯文本，不做 JSON 美化）',
    'col.method': '方法',
    'col.url': 'URL',
    'col.host': '域名',
    'col.path': '路径',
    'col.status': '状态',
    'col.resourceType': '类型',
    'col.time': '耗时',
    'col.size': '大小',
    'col.started': '时间',
    'filter.searchPlaceholder': '按 URL 关键字搜索…',
    'filter.method': '方法',
    'filter.status': '状态码',
    'filter.resourceType': '资源类型',
    'filter.all': '全部',
    'filter.clear': '清除筛选',
    'hide.toggle': '隐藏静态资源',
    'mode.a': '简单格式化',
    'mode.b': '纯原始',
    'mode.aButton': '模式 A',
    'mode.bButton': '模式 B',
    'mode.aHint': '加标题段与段标签，正文逐字符原样',
    'mode.bHint': '不加任何标题，直接拼接',
    'copy.button': '复制请求 + 响应（原始）',
    'copy.buttonCurl': '复制为 cURL',
    'copy.hintSelect': '请先选中一条请求',
    'copy.notEnabled': '该功能暂未启用',
    'copy.cancelled': '已取消复制',
    'copy.fetchingTimeout': '响应体仍在获取中，请稍后重试',
    'copy.metaHeader': '===== META =====',
    'copy.requestSection': '===== REQUEST =====',
    'copy.responseSection': '===== RESPONSE =====',
    'copy.requestBody': '[Request Body]',
    'copy.responseBody': '[Response Body]',
    'copy.meta.started': '开始时间',
    'copy.meta.time': '总耗时',
    'copy.meta.resourceType': '资源类型',
    'copy.meta.mimeType': 'MIME 类型',
    'toast.copied': '已复制到剪贴板',
    'toast.copyFailed': '复制失败：{reason}',
    'toast.copyFailedUnknown': '未知原因',
    'empty.title': '暂无网络请求',
    'empty.hint': '在页面中触发请求后，列表会自动更新。',
    'empty.noMatch': '没有匹配的请求',
    'privacy.link': '隐私政策',
    'privacy.title': '隐私政策',
    'large.confirm': '该响应较大（{size}），是否继续复制？',
    'large.badge': '大响应',
    'content.unavailable': '（响应体不可用）',
    'content.fetching': '（正在获取响应体…）',
    'content.binaryOmitted': '[Binary content omitted: {mime}, {bytes} bytes]',
    'content.base64Omitted': '[Base64 content omitted: length {length}]',
    'selection.evicted': '选中的请求已被淘汰',
    'list.count': '共 {count} 条',
    'list.cached': '缓存 {count}/{capacity} 条',
    'list.showCount': '显示 {shown}/{total} 条',
    'list.hiddenCount': '显示 {shown}/{total} 条 · 已隐藏 {hidden}',
    'list.clear': '清除网络日志',
    'app.loading': '加载中…',
    'contextmenu.copyRequestResponse': '复制请求 + 响应（原始）',
    'contextmenu.copySelected': '复制选中({count})',
    'multi.selectAll': '全选',
    'multi.copySelected': '复制选中({count})',
    'multi.selectedCount': '已选 {count} 条',
    'multi.largeConfirm': '本批含 {count} 条大响应（最大 {size}），是否继续复制？',
    'detail.title': '请求明细',
    'detail.close': '关闭',
    'detail.copyButton': '复制请求 + 响应（原始）',
    'detail.evicted': '该请求已被淘汰，明细已关闭',
  },
  en: {
    'panel.name': 'Raw Copy',
    'panel.title': 'Raw Request Copier',
    'panel.subtitle': 'Select one request and copy its full request + response as plain text.',
    'col.method': 'Method',
    'col.url': 'URL',
    'col.host': 'Domain',
    'col.path': 'Path',
    'col.status': 'Status',
    'col.resourceType': 'Type',
    'col.time': 'Time',
    'col.size': 'Size',
    'col.started': 'Started',
    'filter.searchPlaceholder': 'Search by URL…',
    'filter.method': 'Method',
    'filter.status': 'Status',
    'filter.resourceType': 'Resource type',
    'filter.all': 'All',
    'filter.clear': 'Clear filters',
    'hide.toggle': 'Hide static assets',
    'mode.a': 'Formatted',
    'mode.b': 'Raw',
    'mode.aButton': 'Mode A',
    'mode.bButton': 'Mode B',
    'mode.aHint': 'Add section headers only; body stays byte-for-byte identical',
    'mode.bHint': 'Concatenate directly without any headers',
    'copy.button': 'Copy Request + Response (Raw)',
    'copy.buttonCurl': 'Copy as cURL',
    'copy.hintSelect': 'Select a request first',
    'copy.notEnabled': 'This action is not available yet',
    'copy.cancelled': 'Copy cancelled',
    'copy.fetchingTimeout': 'The response body is still being fetched, please retry shortly',
    'copy.metaHeader': '===== META =====',
    'copy.requestSection': '===== REQUEST =====',
    'copy.responseSection': '===== RESPONSE =====',
    'copy.requestBody': '[Request Body]',
    'copy.responseBody': '[Response Body]',
    'copy.meta.started': 'Started',
    'copy.meta.time': 'Duration',
    'copy.meta.resourceType': 'Resource type',
    'copy.meta.mimeType': 'MIME type',
    'toast.copied': 'Copied to clipboard',
    'toast.copyFailed': 'Copy failed: {reason}',
    'toast.copyFailedUnknown': 'Unknown reason',
    'empty.title': 'No network requests yet',
    'empty.hint': 'Requests will appear here automatically.',
    'empty.noMatch': 'No matching requests',
    'privacy.link': 'Privacy Policy',
    'privacy.title': 'Privacy Policy',
    'large.confirm': 'This response is large ({size}). Copy anyway?',
    'large.badge': 'Large',
    'content.unavailable': '(response body unavailable)',
    'content.fetching': '(fetching response body…)',
    'content.binaryOmitted': '[Binary content omitted: {mime}, {bytes} bytes]',
    'content.base64Omitted': '[Base64 content omitted: length {length}]',
    'selection.evicted': 'The selected request has been evicted',
    'list.count': '{count} total',
    'list.cached': 'Cached {count}/{capacity}',
    'list.showCount': 'Showing {shown}/{total}',
    'list.hiddenCount': 'Showing {shown}/{total} · {hidden} hidden',
    'list.clear': 'Clear network log',
    'app.loading': 'Loading…',
    'contextmenu.copyRequestResponse': 'Copy Request + Response (Raw)',
    'contextmenu.copySelected': 'Copy Selected ({count})',
    'multi.selectAll': 'Select all',
    'multi.copySelected': 'Copy Selected ({count})',
    'multi.selectedCount': '{count} selected',
    'multi.largeConfirm': 'This batch contains {count} large response(s) (max {size}). Copy anyway?',
    'detail.title': 'Request details',
    'detail.close': 'Close',
    'detail.copyButton': 'Copy Request + Response (Raw)',
    'detail.evicted': 'This request has been evicted; details closed',
  },
};
let currentLang = DEFAULT_LANG;
export function setLanguage(lang) {
  if (SUPPORTED_LANGS.indexOf(lang) !== -1) {
    currentLang = lang;
  }
  return currentLang;
}
export function getLanguage() {
  return currentLang;
}
export function t(key, vars) {
  if (typeof key !== 'string' || key.length === 0) {
    return '';
  }
  const langTable = dict[currentLang] || dict[DEFAULT_LANG];
  let text = langTable[key];
  if (text === undefined && langTable !== dict[DEFAULT_LANG]) {
    text = dict[DEFAULT_LANG][key];
  }
  if (text === undefined) {
    if (typeof console !== 'undefined' && typeof console.warn === 'function') {
      console.warn('[E_I18N_MISSING_KEY] ' + key);
    }
    return key;
  }
  if (vars && typeof text === 'string') {
    return text.replace(/\{(\w+)\}/g, function (match, name) {
      return Object.prototype.hasOwnProperty.call(vars, name)
        ? String(vars[name])
        : match;
    });
  }
  return text;
}
export default { t, dict, setLanguage, getLanguage, DEFAULT_LANG, SUPPORTED_LANGS };