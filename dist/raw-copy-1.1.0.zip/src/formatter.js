export const MODE_A = 'formatted';
export const MODE_B = 'raw';
export const META_HEADER = '===== META =====';
export const REQUEST_SECTION = '===== REQUEST =====';
export const RESPONSE_SECTION = '===== RESPONSE =====';
export const REQUEST_BODY_LABEL = '[Request Body]';
export const RESPONSE_BODY_LABEL = '[Response Body]';
const HTTP_VERSION_FALLBACK = 'HTTP/1.1';
const METHOD_FALLBACK = '?';
const META_LABEL_STARTED = '开始时间';
const META_LABEL_TIME = '总耗时';
const META_LABEL_RESOURCE_TYPE = '资源类型';
const META_LABEL_MIME = 'MIME 类型';
function isObject(value) {
  return value !== null && typeof value === 'object';
}
function asString(value) {
  if (typeof value === 'string') {
    return value;
  }
  if (value === null || value === undefined) {
    return '';
  }
  return String(value);
}
function hasText(value) {
  return typeof value === 'string' && value.length > 0;
}
function hasOwn(obj, key) {
  return Object.prototype.hasOwnProperty.call(obj, key);
}
function formatHeaderLine(header) {
  if (typeof header === 'string') {
    return header.length > 0 ? header : null;
  }
  if (isObject(header)) {
    return asString(header.name) + ': ' + asString(header.value);
  }
  if (header === null || header === undefined) {
    return null;
  }
  const text = asString(header);
  return text.length > 0 ? text : null;
}
function appendHeaderLines(lines, headers) {
  if (!Array.isArray(headers)) {
    return;
  }
  for (let i = 0; i < headers.length; i += 1) {
    const line = formatHeaderLine(headers[i]);
    if (line !== null) {
      lines.push(line);
    }
  }
}
function buildRequestStartLine(record) {
  const method = hasText(record.method) ? record.method : METHOD_FALLBACK;
  const url = asString(record.url);
  const version = hasText(record.httpVersion) ? record.httpVersion : HTTP_VERSION_FALLBACK;
  return method + ' ' + url + ' ' + version;
}
function buildResponseStartLine(record) {
  const version = hasText(record.httpVersion) ? record.httpVersion : HTTP_VERSION_FALLBACK;
  const status =
    typeof record.status === 'number' && Number.isFinite(record.status)
      ? String(record.status)
      : '0';
  const statusText = asString(record.statusText);
  return statusText.length > 0
    ? version + ' ' + status + ' ' + statusText
    : version + ' ' + status;
}
function hasBody(body) {
  return typeof body === 'string' && body.length > 0;
}
function resolveBodies(record, options) {
  const requestBody = hasOwn(options, 'requestBody') ? options.requestBody : record.requestBody;
  let fallbackResponse = '';
  if (isObject(record.responseContent) && typeof record.responseContent.text === 'string') {
    fallbackResponse = record.responseContent.text;
  }
  const responseBody = hasOwn(options, 'responseBody') ? options.responseBody : fallbackResponse;
  return { requestBody, responseBody };
}
function buildRequestLines(record, body, withLabel) {
  const lines = [buildRequestStartLine(record)];
  appendHeaderLines(lines, record.requestHeaders);
  if (hasBody(body)) {
    lines.push('');
    if (withLabel) {
      lines.push(REQUEST_BODY_LABEL);
    }
    lines.push(body);
  }
  return lines;
}
function buildResponseLines(record, body, withLabel) {
  const lines = [buildResponseStartLine(record)];
  appendHeaderLines(lines, record.responseHeaders);
  if (hasBody(body)) {
    lines.push('');
    if (withLabel) {
      lines.push(RESPONSE_BODY_LABEL);
    }
    lines.push(body);
  }
  return lines;
}
function buildMetaLines(record) {
  const lines = [];
  if (hasText(record.startedDateTime)) {
    lines.push(META_LABEL_STARTED + ': ' + record.startedDateTime);
  }
  if (typeof record.time === 'number' && Number.isFinite(record.time)) {
    lines.push(META_LABEL_TIME + ': ' + record.time + ' ms');
  }
  if (hasText(record.resourceType)) {
    lines.push(META_LABEL_RESOURCE_TYPE + ': ' + record.resourceType);
  }
  const mimeType =
    isObject(record.responseContent) && hasText(record.responseContent.mimeType)
      ? record.responseContent.mimeType
      : '';
  if (mimeType.length > 0) {
    lines.push(META_LABEL_MIME + ': ' + mimeType);
  }
  return lines;
}
export function buildCopyText(record, mode = MODE_A, options = {}) {
  if (!isObject(record)) {
    return '';
  }
  const opts = isObject(options) ? options : {};
  const { requestBody, responseBody } = resolveBodies(record, opts);
  const isRaw = mode === MODE_B;
  const requestLines = buildRequestLines(record, requestBody, !isRaw);
  const responseLines = buildResponseLines(record, responseBody, !isRaw);
  if (isRaw) {
    return requestLines.concat([''], responseLines).join('\n');
  }
  const lines = [];
  if (opts.includeMeta !== false) {
    const metaLines = buildMetaLines(record);
    if (metaLines.length > 0) {
      lines.push(META_HEADER);
      for (let i = 0; i < metaLines.length; i += 1) {
        lines.push(metaLines[i]);
      }
      lines.push('');
    }
  }
  lines.push(REQUEST_SECTION);
  for (let i = 0; i < requestLines.length; i += 1) {
    lines.push(requestLines[i]);
  }
  lines.push('');
  lines.push(RESPONSE_SECTION);
  for (let i = 0; i < responseLines.length; i += 1) {
    lines.push(responseLines[i]);
  }
  return lines.join('\n');
}
export default { buildCopyText, MODE_A, MODE_B };