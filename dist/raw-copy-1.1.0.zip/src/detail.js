import { buildCopyText, MODE_A } from './formatter.js';
export function buildDetailText(record, resolveBody) {
  if (typeof resolveBody !== 'function') {
    return buildCopyText(record, MODE_A);
  }
  return buildCopyText(record, MODE_A, { responseBody: resolveBody(record) });
}
function toElement(el) {
  if (el && typeof el === 'object') {
    return el;
  }
  return null;
}
export function createDetailView(options = {}) {
  const opts = options && typeof options === 'object' ? options : {};
  const container = toElement(opts.container);
  const body = toElement(opts.body) || (container && 'textContent' in container ? container : null);
  const resolveText = typeof opts.resolveText === 'function' ? opts.resolveText : null;
  const onClose = typeof opts.onClose === 'function' ? opts.onClose : null;
  let currentId = null;
  function setProp(el, name, value) {
    if (!el) {
      return;
    }
    try {
      el[name] = value;
    } catch (_err) {
    }
  }
  function safeResolveText(id) {
    if (!resolveText) {
      return '';
    }
    try {
      const text = resolveText(id);
      return typeof text === 'string' ? text : text === null || text === undefined ? '' : String(text);
    } catch (_err) {
      return '';
    }
  }
  function safeOnClose(id) {
    if (!onClose) {
      return;
    }
    try {
      onClose(id);
    } catch (_err) {
    }
  }
  function open(id) {
    if (id === undefined || id === null) {
      return false;
    }
    currentId = id;
    if (body) {
      setProp(body, 'textContent', safeResolveText(id));
    }
    if (container) {
      setProp(container, 'hidden', false);
    }
    return true;
  }
  function close() {
    if (currentId === null) {
      return false;
    }
    const closedId = currentId;
    currentId = null;
    if (body) {
      setProp(body, 'textContent', '');
    }
    if (container) {
      setProp(container, 'hidden', true);
    }
    safeOnClose(closedId);
    return true;
  }
  function onEvict(id) {
    if (currentId === null || id !== currentId) {
      return false;
    }
    close();
    return true;
  }
  function isOpen() {
    return currentId !== null;
  }
  function currentIdValue() {
    return currentId;
  }
  return {
    open,
    close,
    isOpen,
    currentId: currentIdValue,
    onEvict,
  };
}
export default { buildDetailText, createDetailView };