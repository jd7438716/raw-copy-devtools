export const DEFAULT_HTTP_VERSION = 'HTTP/1.1';
export const MAX_CONCURRENT_ENRICH = 4;
export const MAX_ENRICH_QUEUE = 200;
export const ENRICH_FETCH_TIMEOUT_MS = 10000;
function normalizePositive(value, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 1) {
    return fallback;
  }
  return Math.floor(n);
}
function asObject(value) {
  return value && typeof value === 'object' ? value : null;
}
function asString(value, fallback = '') {
  return typeof value === 'string' ? value : fallback;
}
function asNumber(value, fallback = 0) {
  return typeof value === 'number' && Number.isFinite(value) ? value : fallback;
}
function normalizeHeaders(headers) {
  if (!Array.isArray(headers)) {
    return [];
  }
  const out = [];
  for (let i = 0; i < headers.length; i += 1) {
    const header = asObject(headers[i]);
    if (!header) {
      continue;
    }
    out.push({ name: asString(header.name), value: asString(header.value) });
  }
  return out;
}
function resolveInjectedId(idOrOptions) {
  let value = idOrOptions;
  if (value && typeof value === 'object') {
    value = value.id;
  }
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}
export function normalize(harEntry, idOrOptions) {
  const entry = asObject(harEntry) || {};
  const request = asObject(entry.request) || {};
  const response = asObject(entry.response) || {};
  const content = asObject(response.content) || {};
  const postData = asObject(request.postData);
  const responseText = typeof content.text === 'string' ? content.text : null;
  const rawHttpVersion = asString(request.httpVersion);
  return {
    id: resolveInjectedId(idOrOptions),
    method: asString(request.method),
    url: asString(request.url),
    httpVersion: rawHttpVersion || DEFAULT_HTTP_VERSION,
    requestHeaders: normalizeHeaders(request.headers),
    requestBody:
      postData && typeof postData.text === 'string' ? postData.text : undefined,
    status: asNumber(response.status, 0),
    statusText: asString(response.statusText),
    responseHeaders: normalizeHeaders(response.headers),
    responseContent: {
      text: responseText,
      encoding: typeof content.encoding === 'string' ? content.encoding : null,
      mimeType: asString(content.mimeType),
      size:
        typeof content.size === 'number' &&
        Number.isFinite(content.size) &&
        content.size >= 0
          ? content.size
          : responseText === null
            ? 0
            : responseText.length,
    },
    time: asNumber(entry.time, 0),
    startedDateTime: asString(entry.startedDateTime),
    resourceType: asString(entry._resourceType) || asString(entry.resourceType) || '',
  };
}
function utf8ByteLength(text) {
  if (typeof text !== 'string' || text.length === 0) {
    return 0;
  }
  if (typeof TextEncoder === 'function') {
    return new TextEncoder().encode(text).length;
  }
  let bytes = 0;
  for (let i = 0; i < text.length; i += 1) {
    const code = text.charCodeAt(i);
    if (code < 0x80) {
      bytes += 1;
    } else if (code < 0x800) {
      bytes += 2;
    } else if (code >= 0xd800 && code <= 0xdbff) {
      bytes += 4;
      i += 1;
    } else {
      bytes += 3;
    }
  }
  return bytes;
}
export function applyContent(record, text, encoding) {
  if (!asObject(record) || typeof text !== 'string') {
    return false;
  }
  const rc = asObject(record.responseContent) || {};
  rc.text = text;
  if (typeof encoding === 'string' && encoding.length > 0) {
    rc.encoding = encoding;
  }
  const size = rc.size;
  if (typeof size !== 'number' || !Number.isFinite(size) || size <= 0) {
    rc.size = utf8ByteLength(text);
  }
  record.responseContent = rc;
  return true;
}
function fetchContent(harEntry) {
  return new Promise(function executor(resolve) {
    let settled = false;
    let timer = null;
    function done(text, encoding) {
      if (settled) {
        return;
      }
      settled = true;
      if (timer !== null) {
        clearTimeout(timer);
        timer = null;
      }
      resolve({
        text: typeof text === 'string' ? text : null,
        encoding: typeof encoding === 'string' ? encoding : null,
      });
    }
    timer = setTimeout(function onFetchTimeout() {
      done(null, null);
    }, ENRICH_FETCH_TIMEOUT_MS);
    function fromObject(obj) {
      if (obj && typeof obj === 'object') {
        const text =
          typeof obj.content === 'string'
            ? obj.content
            : typeof obj.text === 'string'
              ? obj.text
              : null;
        const encoding =
          typeof obj.encoding === 'string'
            ? obj.encoding
            : typeof obj.contentEncoding === 'string'
              ? obj.contentEncoding
              : null;
        done(text, encoding);
      } else {
        done(null, null);
      }
    }
    let ret;
    try {
      ret = harEntry.getContent(function onContent(content, encoding) {
        done(content, encoding);
      });
    } catch (_err) {
      try {
        ret = harEntry.getContent();
      } catch (_err2) {
        done(null, null);
        return;
      }
    }
    if (ret && typeof ret.then === 'function') {
      try {
        ret.then(fromObject, function onReject() {
          done(null, null);
        });
      } catch (_err3) {
        done(null, null);
      }
    }
  });
}
function noopHandle() {
  return {
    uninstall() {
    },
  };
}
export function installCapture(options = {}) {
  const opts = asObject(options) || {};
  const store = opts.store;
  const onAdd = opts.onAdd;
  const onUpdate = opts.onUpdate;
  if (!store || typeof store.add !== 'function') {
    return noopHandle();
  }
  const chromeApi =
    opts.chrome !== undefined
      ? opts.chrome
      : typeof globalThis !== 'undefined'
        ? globalThis.chrome
        : undefined;
  const network =
    chromeApi && chromeApi.devtools ? chromeApi.devtools.network : undefined;
  const onRequestFinished = network ? network.onRequestFinished : undefined;
  if (!onRequestFinished || typeof onRequestFinished.addListener !== 'function') {
    return noopHandle();
  }
  const maxConcurrent = normalizePositive(opts.maxConcurrent, MAX_CONCURRENT_ENRICH);
  const maxQueue = normalizePositive(opts.maxQueue, MAX_ENRICH_QUEUE);
  let active = true;
  let inFlight = 0;
  const queue = [];
  function pump() {
    while (active && inFlight < maxConcurrent && queue.length > 0) {
      const task = queue.shift();
      inFlight += 1;
      Promise.resolve()
        .then(task.run)
        .catch(function onTaskError() {
        })
        .then(function onTaskDone() {
          inFlight -= 1;
          pump();
        });
    }
  }
  function schedule(task) {
    if (!active || queue.length >= maxQueue) {
      task.drop();
      return;
    }
    queue.push(task);
    pump();
  }
  function maybeEnrich(harEntry, record, id) {
    const rc = record ? record.responseContent : null;
    const hasText = !!rc && typeof rc.text === 'string' && rc.text.length > 0;
    if (hasText) {
      return;
    }
    if (!harEntry || typeof harEntry.getContent !== 'function') {
      return;
    }
    if (
      typeof store.markPending !== 'function' ||
      typeof store.update !== 'function' ||
      typeof store.resolvePending !== 'function'
    ) {
      return;
    }
    store.markPending(id);
    schedule({
      run: function run() {
        return fetchContent(harEntry).then(function onContent(result) {
          if (typeof store.get === 'function' && store.get(id) !== record) {
            store.rejectPending(id, 'record-evicted');
            return;
          }
          if (result && typeof result.text === 'string') {
            applyContent(record, result.text, result.encoding);
            store.update(id, { responseContent: record.responseContent });
            store.resolvePending(id, true);
            if (typeof onUpdate === 'function') {
              try {
                onUpdate(record, id);
              } catch (_err) {
              }
            }
          } else {
            store.rejectPending(id, 'content-unavailable');
          }
        });
      },
      drop: function drop() {
        store.rejectPending(id, 'enqueue-overflow');
      },
    });
  }
  function handleRequestFinished(harEntry) {
    let record;
    try {
      record = normalize(harEntry);
    } catch (_err) {
      return;
    }
    let id;
    try {
      id = store.add(record);
    } catch (_err) {
      return;
    }
    if (typeof onAdd === 'function') {
      try {
        onAdd(record, id);
      } catch (_err) {
      }
    }
    try {
      maybeEnrich(harEntry, record, id);
    } catch (_err) {
    }
  }
  onRequestFinished.addListener(handleRequestFinished);
  return {
    uninstall() {
      if (!active) {
        return;
      }
      active = false;
      const dropped = queue.splice(0, queue.length);
      for (let i = 0; i < dropped.length; i += 1) {
        try {
          dropped[i].drop();
        } catch (_err) {
        }
      }
      if (typeof onRequestFinished.removeListener === 'function') {
        onRequestFinished.removeListener(handleRequestFinished);
      }
    },
  };
}
export default { normalize, installCapture, applyContent };