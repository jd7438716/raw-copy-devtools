function toIdList(value) {
  return Array.isArray(value) ? value.slice() : [];
}
function toDelta(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) {
    return 0;
  }
  return Math.trunc(n);
}
export function createSelection(options = {}) {
  const opts = options && typeof options === 'object' ? options : {};
  const onChange = typeof opts.onChange === 'function' ? opts.onChange : null;
  let list = toIdList(opts.ids);
  let selectedId = null;
  function indexOfId(id) {
    return list.indexOf(id);
  }
  function currentIndex() {
    return selectedId === null ? -1 : indexOfId(selectedId);
  }
  function emit() {
    if (!onChange) {
      return;
    }
    try {
      onChange(selectedId, currentIndex());
    } catch (_err) {
    }
  }
  function setSelected(next) {
    if (next === selectedId) {
      return false;
    }
    selectedId = next;
    emit();
    return true;
  }
  function selectAt(index) {
    const i = Number(index);
    if (!Number.isInteger(i) || i < 0 || i >= list.length) {
      return false;
    }
    const id = list[i];
    if (id === undefined || id === null) {
      return false;
    }
    setSelected(id);
    return true;
  }
  function selectId(id) {
    if (id === undefined || id === null || indexOfId(id) === -1) {
      return false;
    }
    if (id === selectedId) {
      return true;
    }
    selectedId = id;
    emit();
    return true;
  }
  function move(delta) {
    const step = toDelta(delta);
    if (step === 0 || list.length === 0) {
      return false;
    }
    const at = currentIndex();
    let target;
    if (at === -1) {
      target = step > 0 ? 0 : list.length - 1;
    } else {
      target = at + step;
      if (target < 0) {
        target = 0;
      } else if (target > list.length - 1) {
        target = list.length - 1;
      }
    }
    if (target === at) {
      return false;
    }
    const id = list[target];
    if (id === undefined || id === null) {
      return false;
    }
    selectedId = id;
    emit();
    return true;
  }
  function current() {
    if (selectedId === null) {
      return null;
    }
    return indexOfId(selectedId) === -1 ? null : selectedId;
  }
  function onEvict(id) {
    if (selectedId !== null && id === selectedId) {
      selectedId = null;
      emit();
      return true;
    }
    return false;
  }
  function setIds(next) {
    list = toIdList(next);
    if (selectedId !== null && indexOfId(selectedId) === -1) {
      selectedId = null;
      emit();
    }
    return current();
  }
  function reset() {
    if (selectedId === null) {
      return false;
    }
    selectedId = null;
    emit();
    return true;
  }
  function index() {
    return currentIndex();
  }
  function ids() {
    return list.slice();
  }
  function size() {
    return list.length;
  }
  return {
    setIds,
    selectAt,
    move,
    selectId,
    current,
    onEvict,
    reset,
    index,
    ids,
    size,
  };
}
export default { createSelection };