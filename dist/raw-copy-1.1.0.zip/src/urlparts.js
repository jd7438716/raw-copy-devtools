export function splitUrl(url) {
  const raw = typeof url === 'string' ? url : '';
  if (raw === '') {
    return { host: '', path: '' };
  }
  if (typeof URL === 'function') {
    try {
      const parsed = new URL(raw);
      const host = parsed.host || '';
      if (host === '') {
        return { host: '', path: raw };
      }
      const path = (parsed.pathname || '') + (parsed.search || '') + (parsed.hash || '');
      return { host: host, path: path || '/' };
    } catch (_err) {
    }
  }
  const m = /^([a-z][a-z0-9+.-]*:\/\/)([^/?#]+)([\s\S]*)$/i.exec(raw);
  if (m) {
    const rest = m[3] || '';
    return { host: m[2], path: rest || '/' };
  }
  return { host: '', path: raw };
}
export default { splitUrl };