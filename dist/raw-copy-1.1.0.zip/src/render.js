export function computeWindow(options) {
  const opts = options && typeof options === 'object' ? options : {};
  const rawRowHeight = Number(opts.rowHeight);
  const rowHeight = Number.isFinite(rawRowHeight) && rawRowHeight > 0 ? rawRowHeight : 1;
  const rawTotal = Number(opts.total);
  const total = Number.isFinite(rawTotal) && rawTotal > 0 ? Math.floor(rawTotal) : 0;
  const rawTop = Number(opts.scrollTop);
  const scrollTop = Number.isFinite(rawTop) && rawTop > 0 ? rawTop : 0;
  const rawViewport = Number(opts.viewportHeight);
  const viewportHeight = Number.isFinite(rawViewport) && rawViewport > 0 ? rawViewport : 0;
  const rawOverscan = Number(opts.overscan);
  const overscan = Number.isFinite(rawOverscan) && rawOverscan > 0 ? Math.floor(rawOverscan) : 0;
  if (total === 0) {
    return { start: 0, end: 0, offset: 0, count: 0 };
  }
  const firstVisible = Math.floor(scrollTop / rowHeight);
  const lastVisibleExclusive = Math.ceil((scrollTop + viewportHeight) / rowHeight);
  const start = Math.max(0, firstVisible - overscan);
  const end = Math.min(
    total,
    Math.max(lastVisibleExclusive, firstVisible + 1) + overscan,
  );
  return {
    start,
    end,
    offset: start * rowHeight,
    count: Math.max(0, end - start),
  };
}
function isScrollable(node) {
  if (!node) {
    return false;
  }
  const inline = node.style ? node.style.overflowY : '';
  if (inline === 'auto' || inline === 'scroll' || inline === 'overlay') {
    return true;
  }
  if (typeof getComputedStyle === 'function') {
    try {
      const computed = getComputedStyle(node);
      const value = computed ? computed.overflowY : '';
      if (value === 'auto' || value === 'scroll' || value === 'overlay') {
        return true;
      }
    } catch (_err) {
    }
  }
  const clientHeight = Number(node.clientHeight);
  const scrollHeight = Number(node.scrollHeight);
  return clientHeight > 0 && scrollHeight > clientHeight;
}
function findScrollParent(node) {
  let current = node ? node.parentElement : null;
  while (current) {
    if (isScrollable(current)) {
      return current;
    }
    current = current.parentElement;
  }
  return null;
}
function noopList() {
  return {
    setData() {
    },
    scrollToId() {
      return false;
    },
    refresh() {
    },
  };
}
export function createVirtualList(options) {
  const opts = options && typeof options === 'object' ? options : {};
  const container = opts.container;
  const renderRow = opts.renderRow;
  if (!container || typeof container.appendChild !== 'function') {
    return noopList();
  }
  const rawRowHeight = Number(opts.rowHeight);
  const rowHeight = Number.isFinite(rawRowHeight) && rawRowHeight > 0 ? rawRowHeight : 1;
  const rawOverscan = Number(opts.overscan);
  const overscan =
    Number.isFinite(rawOverscan) && rawOverscan >= 0 ? Math.floor(rawOverscan) : 5;
  const doc =
    container.ownerDocument ||
    (typeof document !== 'undefined' ? document : null);
  if (!doc || typeof doc.createElement !== 'function') {
    return noopList();
  }
  const scrollElement = findScrollParent(container) || container;
  let items = [];
  let version = 0;
  const pool = [];
  const spacer = doc.createElement('div');
  spacer.className = 'list__spacer';
  spacer.style.position = 'relative';
  spacer.style.width = '100%';
  spacer.style.height = '0px';
  container.appendChild(spacer);
  function viewportHeight() {
    const fromScroll = Number(scrollElement.clientHeight);
    if (Number.isFinite(fromScroll) && fromScroll > 0) {
      return fromScroll;
    }
    const fromContainer = Number(container.clientHeight);
    return Number.isFinite(fromContainer) && fromContainer > 0 ? fromContainer : 0;
  }
  function contentScrollTop() {
    const base = Number(container.offsetTop) || 0;
    const top = Number(scrollElement.scrollTop) || 0;
    return Math.max(0, top - base);
  }
  function ensurePool(size) {
    let guard = 0;
    while (pool.length < size && guard < 10000) {
      const el = doc.createElement('div');
      el.className = 'row';
      el.style.position = 'absolute';
      el.style.left = '0';
      el.style.right = '0';
      el.style.top = '0';
      el.style.height = rowHeight + 'px';
      el.style.transform = 'translateY(0px)';
      if (typeof el.setAttribute === 'function') {
        el.setAttribute('role', 'row');
      }
      container.appendChild(el);
      pool.push(el);
      guard += 1;
    }
    while (pool.length > size) {
      const el = pool.pop();
      if (el && el.parentElement === container && typeof container.removeChild === 'function') {
        container.removeChild(el);
      }
    }
  }
  function renderWindow() {
    const win = computeWindow({
      scrollTop: contentScrollTop(),
      viewportHeight: viewportHeight(),
      rowHeight,
      total: items.length,
      overscan,
    });
    ensurePool(win.count);
    for (let k = 0; k < win.count; k += 1) {
      const index = win.start + k;
      const el = pool[k];
      const record = items[index];
      if (el.__rowIndex !== index || el.__version !== version) {
        if (typeof renderRow === 'function') {
          renderRow(record, el, index);
        }
        el.__rowIndex = index;
        el.__version = version;
      }
      el.style.transform = 'translateY(' + index * rowHeight + 'px)';
      if (typeof el.setAttribute === 'function') {
        el.setAttribute('data-index', String(index));
        el.setAttribute(
          'data-id',
          record && record.id !== undefined && record.id !== null ? String(record.id) : '',
        );
      }
    }
  }
  function onScroll() {
    renderWindow();
  }
  if (scrollElement && typeof scrollElement.addEventListener === 'function') {
    scrollElement.addEventListener('scroll', onScroll);
  }
  if (typeof globalThis !== 'undefined' && typeof globalThis.addEventListener === 'function') {
    globalThis.addEventListener('resize', onScroll);
  }
  function setData(next) {
    items = Array.isArray(next) ? next : [];
    version += 1;
    spacer.style.height = items.length * rowHeight + 'px';
    renderWindow();
  }
  function scrollToId(id) {
    let index = -1;
    for (let i = 0; i < items.length; i += 1) {
      const record = items[i];
      if (record && record.id === id) {
        index = i;
        break;
      }
    }
    if (index < 0) {
      return false;
    }
    const base = Number(container.offsetTop) || 0;
    if (scrollElement && typeof scrollElement.scrollTop === 'number') {
      scrollElement.scrollTop = base + index * rowHeight;
    }
    renderWindow();
    return true;
  }
  function refresh() {
    version += 1;
    renderWindow();
  }
  void opts.onSelect;
  return { setData, scrollToId, refresh };
}
export default { computeWindow, createVirtualList };