export const DEFAULT_LARGE_THRESHOLD = 10 * 1024 * 1024;
const BINARY_MIME_PREFIXES = ['image/', 'audio/', 'video/', 'font/'];
const BINARY_MIME_EXACT = new Set([
  'application/octet-stream',
  'application/pdf',
  'application/zip',
  'application/gzip',
  'application/x-gzip',
  'application/x-tar',
  'application/x-7z-compressed',
  'application/x-rar-compressed',
  'application/wasm',
  'application/font-woff',
  'application/vnd.ms-fontobject',
  'application/x-font-ttf',
  'application/x-font-woff',
  'application/x-font-opentype',
]);
const TEXT_MIME_EXACT = new Set([
  'application/json',
  'application/xml',
  'application/javascript',
  'application/x-javascript',
  'application/ecmascript',
  'application/x-www-form-urlencoded',
  'application/xhtml+xml',
  'application/manifest+json',
]);
function normalizeMime(mimeType) {
  if (typeof mimeType !== 'string') {
    return '';
  }
  const semi = mimeType.indexOf(';');
  const base = semi === -1 ? mimeType : mimeType.slice(0, semi);
  return base.trim().toLowerCase();
}
function isBinaryMime(mimeType) {
  const mime = normalizeMime(mimeType);
  if (mime.length === 0) {
    return false;
  }
  for (let i = 0; i < BINARY_MIME_PREFIXES.length; i += 1) {
    if (mime.startsWith(BINARY_MIME_PREFIXES[i])) {
      return true;
    }
  }
  return BINARY_MIME_EXACT.has(mime);
}
function isTextMime(mimeType) {
  const mime = normalizeMime(mimeType);
  if (mime.length === 0) {
    return true;
  }
  if (mime.startsWith('text/')) {
    return true;
  }
  if (mime.endsWith('+json') || mime.endsWith('+xml')) {
    return true;
  }
  return TEXT_MIME_EXACT.has(mime);
}
function utf8ByteLength(text) {
  if (typeof text !== 'string' || text.length === 0) {
    return 0;
  }
  if (typeof TextEncoder === 'function') {
    return new TextEncoder().encode(text).length;
  }
  let bytes = 0;
  for (let i = 0; i < text.length; i += 1) {
    const code = text.charCodeAt(i);
    if (code < 0x80) {
      bytes += 1;
    } else if (code < 0x800) {
      bytes += 2;
    } else if (code >= 0xd800 && code <= 0xdbff) {
      bytes += 4;
      i += 1;
    } else {
      bytes += 3;
    }
  }
  return bytes;
}
function resolveByteSize(responseContent) {
  if (!isObject(responseContent)) {
    return 0;
  }
  const size = responseContent.size;
  if (typeof size === 'number' && Number.isFinite(size) && size >= 0) {
    return size;
  }
  return utf8ByteLength(typeof responseContent.text === 'string' ? responseContent.text : '');
}
const BASE64_PATTERN = /^[A-Za-z0-9+/]*={0,2}$/;
function normalizeBase64(raw) {
  return typeof raw === 'string' ? raw.replace(/\s+/g, '') : '';
}
function isWellFormedBase64(candidate) {
  if (typeof candidate !== 'string' || candidate.length === 0) {
    return false;
  }
  if (candidate.length % 4 !== 0) {
    return false;
  }
  if (!BASE64_PATTERN.test(candidate)) {
    return false;
  }
  const padIndex = candidate.indexOf('=');
  if (padIndex !== -1 && candidate.length - padIndex > 2) {
    return false;
  }
  return true;
}
function decodeBase64ToUtf8(raw) {
  const candidate = normalizeBase64(raw);
  if (!isWellFormedBase64(candidate)) {
    return null;
  }
  try {
    const bufferRef =
      typeof Buffer !== 'undefined'
        ? Buffer
        : typeof globalThis !== 'undefined' && globalThis
          ? globalThis.Buffer
          : undefined;
    if (bufferRef && typeof bufferRef.from === 'function') {
      return bufferRef.from(candidate, 'base64').toString('utf8');
    }
    if (typeof atob === 'function') {
      const binary = atob(candidate);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i += 1) {
        bytes[i] = binary.charCodeAt(i);
      }
      if (typeof TextDecoder === 'function') {
        return new TextDecoder('utf-8').decode(bytes);
      }
      return decodeURIComponent(escape(binary));
    }
  } catch (err) {
    return null;
  }
  return null;
}
function isObject(value) {
  return value !== null && typeof value === 'object';
}
export function classifyBody(responseContent, options = {}) {
  void options; // 预留：当前分类逻辑不依赖选项。
  if (!isObject(responseContent)) {
    return { kind: 'unavailable', byteSize: 0 };
  }
  const byteSize = resolveByteSize(responseContent);
  const text = responseContent.text;
  const hasText = typeof text === 'string' && text.length > 0;
  if (!hasText) {
    return { kind: 'unavailable', byteSize };
  }
  const mimeType = responseContent.mimeType;
  const encoding =
    typeof responseContent.encoding === 'string' ? responseContent.encoding.toLowerCase() : '';
  if (encoding === 'base64') {
    if (isTextMime(mimeType)) {
      const decoded = decodeBase64ToUtf8(text);
      if (decoded !== null) {
        return { kind: 'base64-text', text: decoded, byteSize };
      }
    }
    return {
      kind: 'base64-omitted',
      placeholder: '[Base64 content omitted: length ' + text.length + ']',
      byteSize,
    };
  }
  if (isBinaryMime(mimeType)) {
    return {
      kind: 'binary',
      placeholder:
        '[Binary content omitted: ' + normalizeMime(mimeType) + ', ' + byteSize + ' bytes]',
      byteSize,
    };
  }
  return { kind: 'text', text, byteSize };
}
export function isOverThreshold(responseContent, threshold = DEFAULT_LARGE_THRESHOLD) {
  const limit =
    typeof threshold === 'number' && Number.isFinite(threshold)
      ? threshold
      : DEFAULT_LARGE_THRESHOLD;
  return resolveByteSize(responseContent) > limit;
}
export default { classifyBody, isOverThreshold, DEFAULT_LARGE_THRESHOLD };