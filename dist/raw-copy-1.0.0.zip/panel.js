/**
 * panel.js — Raw Copy DevTools 面板入口（TASK-002 / DEL-002；TASK-004 接线列表）。
 *
 * 职责：
 *   1. 建立并导出稳定的 DOM 契约（`els`）与基础 UI 能力（`showToast` / `applyI18n`）；
 *   2. 在启动时把 `panel.html` 中所有 `data-i18n*` 文案经 `t()` 注入（AC-016 / REQ-033）；
 *   3. TASK-004：装配 store / capture / filter / render，实现列表渲染 + 搜索/过滤/虚拟滚动。
 *
 * 明确不做（留给后续 TASK，见 init() 末尾 TODO）：
 *   选中交互（TASK-005）：已实现，见下方「TASK-005」段落与 init() 内 wireSelection()。
 *   复制拼接（TASK-006）：已实现，见 formatter.js 与「TASK-006」段落（buildCurrentCopy）。
 *   剪贴板写入 + Toast（TASK-007）：已实现，见 clipboard.js 与「TASK-007」段落（onCopyClick）。
 *   大响应/二进制/Base64 分类（TASK-008）：已实现，见 content.js 与「TASK-008」段落（resolveResponseBodyText / onCopyClick 阈值确认）。
 *
 * 约束：纯原生 ESM、零第三方依赖；不发起网络；不写任何持久化存储；
 *      渲染不可信数据时必须使用 textContent（禁止以 HTML 字符串方式注入）。
 *
 * @module panel
 */

import { t } from './src/i18n.js';
import { createStore } from './src/store.js';
import { installCapture } from './src/capture.js';
import { applyFilter, collectOptions } from './src/filter.js';
import { createVirtualList } from './src/render.js';
import { createSelection } from './src/selection.js';
import { buildCopyText, MODE_A, MODE_B } from './src/formatter.js';
import { copyText } from './src/clipboard.js';
import { classifyBody, isOverThreshold } from './src/content.js';

/** Toast 自动隐藏时长（ms）。 */
const TOAST_DURATION_MS = 2400;

/** 记录缓存容量（REQ-004 / AC-013）。 */
const STORE_CAPACITY = 1000;

/** 复制前等待异步 enrich 完成的超时（3s，REQ-006 / AC-007）。 */
const PENDING_TIMEOUT_MS = 3000;

/** 虚拟滚动可视区外上下各多渲染的行数（ADR-005）。 */
const LIST_OVERSCAN = 5;

/** 读不到 CSS `--row-height` 时的回退行高（与 styles/panel.css 保持一致）。 */
const FALLBACK_ROW_HEIGHT = 28;

/** 复制模式契约来自 formatter.js（TASK-006）：MODE_A='formatted' / MODE_B='raw'。 */

/** 面板内元素的稳定引用（id 为契约，不随任务演进改名）。 */
export const els = {
  toolbar: document.querySelector('#toolbar'),
  search: document.querySelector('#search'),
  filterMethod: document.querySelector('#filter-method'),
  filterStatus: document.querySelector('#filter-status'),
  filterType: document.querySelector('#filter-type'),

  list: document.querySelector('#list'),
  listBody: document.querySelector('#list-body'),
  empty: document.querySelector('#empty'),

  copyActions: document.querySelector('#copy-actions'),
  copyBtn: document.querySelector('#copy-btn'),
  copyReqBtn: document.querySelector('#copy-req-btn'),
  copyRespBtn: document.querySelector('#copy-resp-btn'),
  copyCurlBtn: document.querySelector('#copy-curl-btn'),

  modeToggle: document.querySelector('#mode-toggle'),
  toast: document.querySelector('#toast'),
  privacyLink: document.querySelector('#privacy-link'),
};

/** 当前复制模式（默认 A，DEC-005）。 */
let copyMode = MODE_A;

/** Toast 隐藏计时器句柄。 */
let toastTimer = null;

/* ------------------------------------------------------------------------- *
 * TASK-005 — 选中交互状态（DEL-005 / REQ-010 / REQ-011 / AC-004）
 *
 * 真实选中逻辑在 src/selection.js（纯逻辑、可 Node 单测）；panel.js 只维护
 * 「当前选中项」模块级引用，供 TASK-006/007 的复制路径读取。选中态唯一。
 * ------------------------------------------------------------------------- */

/** 当前选中项 id（由 selection 回调同步；无选中 → null）。 */
let selectedId = null;

/** 活动 selection 实例（供 renderRow 判定高亮；init 内装配）。 */
let activeSelection = null;

/** getSelected() 的实现注入点（init 内绑定 store；面板未启动时返回 null）。 */
let getSelectedImpl = function noSelection() {
  return null;
};

/** 活动 store 实例（init 内绑定；供 pending 判定，无 store → null）。 */
let activeStore = null;

/**
 * 读取当前选中项记录（TASK-006 formatter 的数据入口，本任务只维护状态）。
 *
 * @returns {Object|null} 选中记录（无选中 → null）
 */
export function getSelected() {
  return getSelectedImpl();
}

/* ------------------------------------------------------------------------- *
 * TASK-006 — 复制拼接接线（DEL-006 / REQ-014..020 / AC-005/006/007/014/015）
 *
 * formatter.buildCopyText 为纯函数（只读单条 record）；本段只负责：
 *   1. 读取当前选中记录；
 *   2. 按当前模式生成复制文本；
 *   3. 暴露生成的文本（`buildCurrentCopy`）。
 * **本任务不写剪贴板** —— 写剪贴板 + 结果 Toast 由 TASK-007 负责（见 TODO）。
 * ------------------------------------------------------------------------- */

/** 最近一次生成的复制文本（供 TASK-007 写剪贴板使用；本任务不写剪贴板）。 */
let lastCopyText = null;

/**
 * 该记录是否正在异步 enrich（pending）。无 store / 非 pending → false。
 *
 * @param {Object|null} record
 * @returns {boolean}
 */
function isRecordPending(record) {
  return !!(
    activeStore &&
    typeof activeStore.isPending === 'function' &&
    record &&
    record.id !== undefined &&
    record.id !== null &&
    activeStore.isPending(record.id)
  );
}

/**
 * 解析选中记录的响应体注入文本（TASK-008 / DEL-008 / REQ-021..024 / AC-010；
 * TASK-004 增加 pending 分支）。
 *
 * 用 `classifyBody` 对 `record.responseContent` 分类：
 *   - pending（异步获取中）→ `t('content.fetching')`（不产出占位，REQ-007 / AC-003）；
 *   - `text` / `base64-text` → 直接用 `text`（文本类**逐字符原样**，保 ADR-006 / AC-007）；
 *   - `binary` / `base64-omitted` → 用 `placeholder` 省略标注；
 *   - `unavailable` → `t('content.unavailable')`（仅客观不可获取的合法场景）。
 *
 * 纯读取、无副作用；不做任何二次处理（不 trim/不转义）。
 *
 * @param {Object|null} record
 * @returns {string} 注入 formatter 的 `options.responseBody`
 */
function resolveResponseBodyText(record) {
  if (!record) {
    return '';
  }
  if (isRecordPending(record)) {
    return t('content.fetching');
  }
  const classified = classifyBody(record.responseContent);
  if (classified.kind === 'text' || classified.kind === 'base64-text') {
    return typeof classified.text === 'string' ? classified.text : '';
  }
  if (classified.kind === 'binary' || classified.kind === 'base64-omitted') {
    return typeof classified.placeholder === 'string' ? classified.placeholder : '';
  }
  return t('content.unavailable');
}

/**
 * 生成当前选中记录的复制文本（纯读取，无副作用）。
 *
 * TASK-008：按响应体分类结果注入 `options.responseBody`——文本类原样注入，
 * 二进制/Base64 降级为占位标注；formatter 的逐字符保真逻辑不变。
 *
 * @param {'formatted'|'raw'} [mode] 复制模式；缺省使用面板当前模式
 * @returns {string|null} 复制文本；无选中 → null
 */
export function buildCurrentCopy(mode) {
  const record = getSelected();
  if (!record) {
    return null;
  }
  const responseBody = resolveResponseBodyText(record);
  return buildCopyText(record, mode || copyMode, { responseBody });
}

/**
 * 读取最近一次生成的复制文本（测试/调试用；TASK-007 将消费它）。
 * @returns {string|null}
 */
export function getLastCopyText() {
  return lastCopyText;
}

/**
 * 把 root 内所有 i18n 占位属性替换为当前语言文案。
 *
 * 支持：
 *   - `data-i18n`              → textContent
 *   - `data-i18n-placeholder`  → placeholder 属性
 *   - `data-i18n-title`        → title 属性
 *   - `data-i18n-aria-label`   → aria-label 属性
 *
 * @param {ParentNode} [root] 默认 document
 * @returns {number} 被注入文本的节点数量
 */
export function applyI18n(root) {
  const scope = root || document;

  const textNodes = scope.querySelectorAll('[data-i18n]');
  for (let i = 0; i < textNodes.length; i += 1) {
    const node = textNodes[i];
    node.textContent = t(node.getAttribute('data-i18n'));
  }

  const placeholderNodes = scope.querySelectorAll('[data-i18n-placeholder]');
  for (let i = 0; i < placeholderNodes.length; i += 1) {
    const node = placeholderNodes[i];
    node.setAttribute('placeholder', t(node.getAttribute('data-i18n-placeholder')));
  }

  const titleNodes = scope.querySelectorAll('[data-i18n-title]');
  for (let i = 0; i < titleNodes.length; i += 1) {
    const node = titleNodes[i];
    node.setAttribute('title', t(node.getAttribute('data-i18n-title')));
  }

  const ariaNodes = scope.querySelectorAll('[data-i18n-aria-label]');
  for (let i = 0; i < ariaNodes.length; i += 1) {
    const node = ariaNodes[i];
    node.setAttribute('aria-label', t(node.getAttribute('data-i18n-aria-label')));
  }

  return textNodes.length;
}

/**
 * 显示一条 Toast。
 *
 * @param {string} message 已本地化的文案
 * @param {'info'|'success'|'error'} [kind='info']
 * @returns {void}
 */
export function showToast(message, kind) {
  const el = els.toast;
  if (!el) {
    return;
  }

  el.textContent = typeof message === 'string' ? message : '';
  el.classList.remove('toast--info', 'toast--success', 'toast--error');
  el.classList.add('toast--' + (kind || 'info'));
  el.setAttribute('data-visible', 'true');

  if (toastTimer !== null) {
    clearTimeout(toastTimer);
  }
  toastTimer = setTimeout(function hideToast() {
    el.setAttribute('data-visible', 'false');
    toastTimer = null;
  }, TOAST_DURATION_MS);
}

/**
 * 切换空态提示的可见性。
 *
 * @param {boolean} visible 是否展示空态
 * @returns {void}
 */
export function setEmptyState(visible) {
  if (els.empty) {
    els.empty.hidden = !visible;
  }
}

/**
 * 读取当前复制模式。
 * @returns {'formatted'|'raw'}
 */
export function getCopyMode() {
  return copyMode;
}

/**
 * 设置复制模式并同步模式切换按钮的视觉状态。
 *
 * @param {'formatted'|'raw'} mode
 * @returns {'formatted'|'raw'} 生效后的模式
 */
export function setCopyMode(mode) {
  copyMode = mode === MODE_B ? MODE_B : MODE_A;

  const toggle = els.modeToggle;
  if (toggle) {
    const isRaw = copyMode === MODE_B;
    toggle.setAttribute('data-mode', copyMode);
    toggle.setAttribute('aria-pressed', isRaw ? 'true' : 'false');
    toggle.setAttribute('title', t(isRaw ? 'mode.bHint' : 'mode.aHint'));

    const valueNode = toggle.querySelector('[data-mode-value]');
    if (valueNode) {
      valueNode.textContent = t(isRaw ? 'mode.b' : 'mode.a');
    }
  }

  return copyMode;
}

/* ------------------------------------------------------------------------- *
 * TASK-004 — 列表渲染 + 搜索/过滤 + 虚拟滚动接线（DEL-004 / REQ-006..009/029）
 *
 * 纯逻辑在 src/filter.js（applyFilter / collectOptions）与 src/render.js
 * （createVirtualList，核心为 computeWindow）。本段只做 DOM 装配：
 *   store 变更 → collectOptions 派生下拉选项 → applyFilter → 倒序（最新在上）
 *   → virtualList.setData → 空态显隐。
 *
 * 未实现（留后续 TASK）：
 *   - 复制（TASK-006/007）：buildCopyText / clipboard。
 *   - 大响应内容分类（TASK-008）：content.classifyBody。
 *   - 选中交互（TASK-005）已接线，见 init() 内 selection / wireSelection()。
 * ------------------------------------------------------------------------- */

/** 读取 CSS 固定行高 `--row-height`，失败回退 28px。 */
function readRowHeight() {
  if (typeof document !== 'undefined' && typeof getComputedStyle === 'function') {
    try {
      const computed = getComputedStyle(document.documentElement);
      const px = parseFloat(computed.getPropertyValue('--row-height'));
      if (Number.isFinite(px) && px > 0) {
        return px;
      }
    } catch (err) {
      // 环境不支持计算样式 → 使用回退值
    }
  }
  return FALLBACK_ROW_HEIGHT;
}

/** 状态码 → 文本（缺失/0 → '-'）。 */
function formatStatus(status) {
  return typeof status === 'number' && Number.isFinite(status) && status > 0
    ? String(status)
    : '-';
}

/** 耗时（ms）→ 文本。 */
function formatTime(time) {
  if (typeof time !== 'number' || !Number.isFinite(time) || time < 0) {
    return '-';
  }
  return Math.round(time) + ' ms';
}

/** 字节数 → 人类可读文本。 */
function formatSize(size) {
  if (typeof size !== 'number' || !Number.isFinite(size) || size < 0) {
    return '-';
  }
  if (size >= 1048576) {
    return (size / 1048576).toFixed(1) + ' MB';
  }
  if (size >= 1024) {
    return (size / 1024).toFixed(1) + ' KB';
  }
  return size + ' B';
}

/** ISO 时间 → HH:MM:SS（缺失 → '-'）。 */
function formatStarted(iso) {
  if (typeof iso !== 'string' || iso.length < 19) {
    return iso || '-';
  }
  return iso.slice(11, 19);
}

/** 惰性构建 7 列（与 panel.html 表头顺序、panel.css `--col-grid` 一致）。 */
function ensureRowColumns(el) {
  if (el.children && el.children.length === 7) {
    return;
  }
  while (el.firstChild) {
    el.removeChild(el.firstChild);
  }
  const classes = [
    'col col--method',
    'col col--url',
    'col col--status',
    'col col--type',
    'col col--time',
    'col col--size',
    'col col--started',
  ];
  for (let i = 0; i < classes.length; i += 1) {
    const span = document.createElement('span');
    span.className = classes[i];
    span.setAttribute('role', 'gridcell');
    el.appendChild(span);
  }
}

/** 行填充回调：只用 textContent（不可信数据，禁止 innerHTML）。 */
function renderRow(record, el) {
  const rec = record || {};
  ensureRowColumns(el);
  const cols = el.children;
  cols[0].textContent = rec.method ? String(rec.method) : '?';
  cols[1].textContent = typeof rec.url === 'string' ? rec.url : '';
  cols[2].textContent = formatStatus(rec.status);
  cols[3].textContent = typeof rec.resourceType === 'string' ? rec.resourceType : '';
  cols[4].textContent = formatTime(rec.time);
  const content = rec.responseContent;
  cols[5].textContent = formatSize(content ? content.size : NaN);
  cols[6].textContent = formatStarted(rec.startedDateTime);

  // TASK-005：选中态高亮（selection.current() 与记录 id 一致 → .is-selected）。
  const selected =
    activeSelection && rec.id !== undefined && rec.id !== null
      ? activeSelection.current() === rec.id
      : false;
  if (el.classList) {
    if (selected) {
      el.classList.add('is-selected');
    } else {
      el.classList.remove('is-selected');
    }
  }
  if (typeof el.setAttribute === 'function') {
    el.setAttribute('aria-selected', selected ? 'true' : 'false');
  }
}

/**
 * 无选中时禁用全部复制按钮（复制动作本身由 TASK-006/007 实现）。
 *
 * @param {boolean} enabled
 * @returns {void}
 */
function setCopyButtonsEnabled(enabled) {
  const buttons = [els.copyBtn, els.copyReqBtn, els.copyRespBtn, els.copyCurlBtn];
  for (let i = 0; i < buttons.length; i += 1) {
    if (buttons[i]) {
      buttons[i].disabled = !enabled;
    }
  }
}

/** 创建一个 <option>。 */
function createOption(value, label) {
  const option = document.createElement('option');
  option.value = value;
  option.textContent = label;
  return option;
}

/** 重建 select 选项（首项为「全部」），并尽量保留原选中值。 */
function fillSelect(select, values) {
  const previous = select.value;
  while (select.firstChild) {
    select.removeChild(select.firstChild);
  }
  select.appendChild(createOption('', t('filter.all')));
  for (let i = 0; i < values.length; i += 1) {
    select.appendChild(createOption(values[i], values[i]));
  }
  // 选项集合变化后恢复原选择；原值已不存在时浏览器会回落为空串（= 不筛）。
  select.value = previous;
}

/** 选项集合指纹缓存：集合未变则不重建（避免每次追加请求都重排下拉框）。 */
const selectCache = new WeakMap();

/** 仅在派生选项变化时重建 select。 */
function syncSelect(select, values) {
  if (!select) {
    return;
  }
  const key = values.join('\u0000');
  if (selectCache.get(select) === key) {
    return;
  }
  fillSelect(select, values);
  selectCache.set(select, key);
}

/** 面板启动：注入 i18n + 接线列表渲染 / 搜索过滤 / 虚拟滚动 / 选中交互。 */
function init() {
  applyI18n(document);
  setCopyMode(MODE_A);

  const store = createStore({ capacity: STORE_CAPACITY });
  activeStore = store;
  const rowHeight = readRowHeight();

  setCopyButtonsEnabled(false);

  /** TASK-006/007 读取入口：当前选中记录（无选中 → null）。 */
  getSelectedImpl = function resolveSelected() {
    if (selectedId === null) {
      return null;
    }
    return store.get(selectedId) || null;
  };

  /** 虚拟列表实例（selection 回调在装配完成后才可能触发，先以 null 兜底）。 */
  let virtualList = null;

  /** 单选状态机：可见列表 id 序列由 refreshView 注入（见下）。 */
  const selection = createSelection({
    ids: [],
    onChange: function onSelectionChange(id) {
      selectedId = id === undefined ? null : id;
      setCopyButtonsEnabled(selectedId !== null);
      if (virtualList && typeof virtualList.refresh === 'function') {
        virtualList.refresh();
      }
    },
  });
  activeSelection = selection;

  virtualList = createVirtualList({
    container: els.listBody,
    rowHeight,
    overscan: LIST_OVERSCAN,
    renderRow,
    onSelect: function onRowSelect(record, index) {
      // 保留虚拟列表的选中回调契约；行点击另经 #list-body 事件委托接线。
      selection.selectAt(index);
    },
  });

  let rafPending = false;

  /** 读取工具栏当前筛选条件。 */
  function readCriteria() {
    return {
      query: els.search ? els.search.value : '',
      method: els.filterMethod ? els.filterMethod.value : '',
      status: els.filterStatus ? els.filterStatus.value : '',
      resourceType: els.filterType ? els.filterType.value : '',
    };
  }

  /** 更新空态标题/提示文案（动态部分用 t() 注入）。 */
  function setEmptyMessage(titleKey, hintKey) {
    if (!els.empty) {
      return;
    }
    const title = els.empty.querySelector('.empty__title');
    if (title) {
      title.textContent = t(titleKey);
    }
    const hint = els.empty.querySelector('.empty__hint');
    if (hint) {
      hint.textContent = hintKey ? t(hintKey) : '';
      hint.hidden = !hintKey;
    }
  }

  /** 空态显隐：无任何请求 vs 有请求但无匹配。 */
  function updateEmptyState(total, shown) {
    if (total === 0) {
      setEmptyMessage('empty.title', 'empty.hint');
      setEmptyState(true);
    } else if (shown === 0) {
      setEmptyMessage('empty.noMatch', null);
      setEmptyState(true);
    } else {
      setEmptyState(false);
    }
  }

  /** 全量重绘：派生选项 → 过滤 → 倒序（最新在上）→ 虚拟列表 + 空态。 */
  function refreshView() {
    const all = store.all();
    const options = collectOptions(all);
    syncSelect(els.filterMethod, options.methods);
    syncSelect(els.filterStatus, options.statuses);
    syncSelect(els.filterType, options.resourceTypes);

    const filtered = applyFilter(all, readCriteria());
    // store.all() 为「最旧→最新」，倒序后即最新在上（新请求追加可见）。
    const display = filtered.slice().reverse();
    virtualList.setData(display);
    // 选中状态跟随【当前可见（已过滤）列表】：序号与虚拟列表 data-index 一致，
    // ↑↓ move 即在此可见列表内切换（REQ-011 / AC-004）。
    selection.setIds(
      display.map(function toId(record) {
        return record && record.id;
      }),
    );
    updateEmptyState(all.length, filtered.length);
  }

  /** rAF 批处理刷新（高频捕获时合并到一帧，护 REQ-029）。 */
  function requestRefresh() {
    if (rafPending) {
      return;
    }
    rafPending = true;
    const schedule =
      typeof requestAnimationFrame === 'function'
        ? requestAnimationFrame
        : function (cb) {
            return setTimeout(cb, 0);
          };
    schedule(function onFrame() {
      rafPending = false;
      refreshView();
    });
  }

  /** 选中项滚动到可视区（键盘移动后调用，保证切换可见）。 */
  function scrollSelectionIntoView() {
    if (!virtualList || typeof virtualList.scrollToId !== 'function') {
      return;
    }
    const id = selection.current();
    if (id !== null) {
      virtualList.scrollToId(id);
    }
  }

  /** 行点击 → 唯一选中，并让 #list 获得焦点（便于随后 ↑↓）。 */
  function onListBodyClick(event) {
    const target = event ? event.target : null;
    if (!target || typeof target.closest !== 'function' || !els.listBody) {
      return;
    }
    const row = target.closest('.row');
    if (!row) {
      return;
    }
    if (typeof els.listBody.contains === 'function' && !els.listBody.contains(row)) {
      return;
    }
    const index = Number(row.getAttribute('data-index'));
    if (Number.isInteger(index) && index >= 0) {
      selection.selectAt(index);
      if (els.list && typeof els.list.focus === 'function') {
        els.list.focus();
      }
    }
  }

  /** ↑/↓ → 在可见列表内切换选中；preventDefault 防页面滚动（REQ-011 / AC-004）。 */
  function onListKeyDown(event) {
    if (!event) {
      return;
    }
    const key = event.key;
    if (key !== 'ArrowDown' && key !== 'ArrowUp') {
      return;
    }
    if (typeof event.preventDefault === 'function') {
      event.preventDefault();
    }
    selection.move(key === 'ArrowDown' ? 1 : -1);
    scrollSelectionIntoView();
  }

  /** 装配选中交互：行点击事件委托 + #list 键盘事件（#list 已设 tabindex=0）。 */
  function wireSelection() {
    if (els.listBody) {
      els.listBody.addEventListener('click', onListBodyClick);
    }
    if (els.list) {
      els.list.addEventListener('keydown', onListKeyDown);
    }
  }

  if (els.search) {
    els.search.addEventListener('input', requestRefresh);
  }
  if (els.filterMethod) {
    els.filterMethod.addEventListener('change', requestRefresh);
  }
  if (els.filterStatus) {
    els.filterStatus.addEventListener('change', requestRefresh);
  }
  if (els.filterType) {
    els.filterType.addEventListener('change', requestRefresh);
  }

  // 捕获：新记录入 store 后驱动列表刷新；异步 enrich 回填后再刷新一次（REQ-005 / AC-008）。
  installCapture({ store, onAdd: requestRefresh, onUpdate: requestRefresh });

  // 环形缓冲淘汰选中项 → 清空选中（REQ-004 / AC-013）；store.clear 同步复位。
  // update → 刷新（异步回填后正文从「获取中」变为真实正文）；evict → 清选中（字节预算兜底）。
  store.subscribe(function onStoreEvent(event) {
    if (!event) {
      return;
    }
    if (event.type === 'add' || event.type === 'update' || event.type === 'evict') {
      requestRefresh();
    }
    if (event.type === 'add' && event.evicted !== null && event.evicted !== undefined) {
      selection.onEvict(event.evicted);
    } else if (event.type === 'evict') {
      selection.onEvict(event.id);
    } else if (event.type === 'clear') {
      selection.reset();
    }
  });

  // TASK-005：行点击 / ↑↓ 键盘选中接线。
  wireSelection();

  if (els.modeToggle) {
    els.modeToggle.addEventListener('click', function onModeToggleClick() {
      setCopyMode(copyMode === MODE_A ? MODE_B : MODE_A);
    });
  }

  /* TASK-007 — 剪贴板写入 + 降级 + Toast（DEL-007 / REQ-025 / REQ-034 / AC-011 / AC-022）
   *
   * 主路径：buildCurrentCopy() 生成文本 → clipboard.copyText() 双路径写入
   * （writeText 优先，execCommand 降级）→ 成功/失败 Toast。内容不经任何网络传输。
   *
   * TASK-008：复制前先做响应体分类注入（buildCurrentCopy）与超阈值确认（REQ-022 / AC-010）。
   */

  /**
   * 大响应二次确认（TASK-008 / REQ-022 / AC-010）。
   *
   * 无 `confirm` 能力的环境（异常/测试）不阻断复制，返回 true。
   *
   * @param {string} size 人类可读大小（如 `10.0 MB`）
   * @returns {boolean} 用户是否确认继续
   */
  function confirmLargeCopy(size) {
    if (typeof confirm !== 'function') {
      return true;
    }
    try {
      return confirm(t('large.confirm', { size: size })) === true;
    } catch (err) {
      return true;
    }
  }

  /**
   * 复制按钮点击处理：无选中 → 提示；超阈值 → 确认；有选中 → 写入剪贴板并 Toast。
   *
   * @returns {Promise<void>}
   */
  async function onCopyClick() {
    let record = getSelected();
    if (!record) {
      showToast(t('copy.hintSelect'), 'error');
      return;
    }

    // 复制竞态（REQ-006 / AC-007）：异步 enrich 未完成时先等待真实正文；
    // 超时 → 明确提示，不输出占位、不静默输出空正文。
    if (isRecordPending(record)) {
      try {
        await activeStore.awaitPending(record.id, PENDING_TIMEOUT_MS);
      } catch (err) {
        showToast(t('copy.fetchingTimeout'), 'error');
        return;
      }
      // 回填可能伴随淘汰；重新读取选中记录。
      record = getSelected();
      if (!record) {
        showToast(t('copy.hintSelect'), 'error');
        return;
      }
    }

    // 大响应：复制前确认（REQ-022 / AC-010）。用户取消 → 不复制并提示。
    if (isOverThreshold(record.responseContent)) {
      const content = record.responseContent || {};
      const rawSize =
        typeof content.size === 'number' && Number.isFinite(content.size)
          ? content.size
          : typeof content.text === 'string'
            ? content.text.length
            : 0;
      if (!confirmLargeCopy(formatSize(rawSize))) {
        showToast(t('copy.cancelled'), 'info');
        return;
      }
    }

    const text = buildCurrentCopy(copyMode);
    if (text === null) {
      showToast(t('copy.hintSelect'), 'error');
      return;
    }
    lastCopyText = text;

    let result;
    try {
      result = await copyText(text);
    } catch (err) {
      // copyText 契约保证不抛；此处仅作最后的防御，避免未处理 Promise 拒绝。
      result = { ok: false, via: 'none', reason: err && err.message ? err.message : String(err) };
    }

    if (result && result.ok) {
      showToast(t('toast.copied'), 'success');
      return;
    }
    const reason = result && result.reason ? result.reason : t('toast.copyFailedUnknown');
    showToast(t('toast.copyFailed', { reason: reason }), 'error');
  }

  if (els.copyBtn) {
    els.copyBtn.addEventListener('click', onCopyClick);
  }

  // P2（REQ-013 / DEC-004）尚未启用：点击给出明确提示，不阻断主路径。
  function onDeferredCopyClick() {
    showToast(t('copy.notEnabled'), 'info');
  }
  const deferredButtons = [els.copyReqBtn, els.copyRespBtn, els.copyCurlBtn];
  for (let i = 0; i < deferredButtons.length; i += 1) {
    if (deferredButtons[i]) {
      deferredButtons[i].addEventListener('click', onDeferredCopyClick);
    }
  }

  // 首帧：填充下拉选项 + 空态。
  refreshView();

  // TASK-008: 大响应/二进制/base64 分类由 content.js 完成，接线见上方 onCopyClick。
  // TASK-009: 隐私入口接线已完成，见文件末尾 wirePrivacyLink()（window.open，无需 tabs 权限）。
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init, { once: true });
} else {
  init();
}

export default {
  els,
  applyI18n,
  showToast,
  setEmptyState,
  getCopyMode,
  setCopyMode,
  getSelected,
  buildCurrentCopy,
  getLastCopyText,
};

/* ------------------------------------------------------------------------- *
 * TASK-009 — 隐私政策入口接线（DEL-010 / REQ-027 / AC-020）
 *
 * panel.html 已提供 <a id="privacy-link" href="privacy.html">。本扩展刻意只申请
 * clipboardWrite 权限（AC-009），因此 chrome.tabs.create 不可用；改用 window.open
 * 打开扩展内的静态页 privacy.html（同源相对路径会解析为
 * chrome-extension://<id>/privacy.html）。阻止默认行为，避免面板自身被导航覆盖。
 *
 * 约束：不发起网络请求；不写任何持久化存储；不新增任何可见文案。
 * ------------------------------------------------------------------------- */

/**
 * 为隐私政策链接接线：点击时在新标签页打开 privacy.html。
 *
 * `type="module"` 脚本在 DOM 解析后延迟执行，故此处可直接读取 `els.privacyLink`。
 * 若 `window.open` 被环境拦截，则回退到 `<a>` 的默认 `href` 行为。
 *
 * @returns {void}
 */
function wirePrivacyLink() {
  const link = els.privacyLink;
  if (!link) {
    return;
  }

  link.addEventListener('click', function onPrivacyLinkClick(event) {
    if (event && typeof event.preventDefault === 'function') {
      event.preventDefault();
    }

    const target = link.getAttribute('href') || 'privacy.html';
    try {
      window.open(target, '_blank');
    } catch (err) {
      if (typeof console !== 'undefined' && typeof console.warn === 'function') {
        console.warn(
          '[E_PRIVACY_OPEN_FAILED] ' + (err && err.message ? err.message : String(err))
        );
      }
    }
  });
}

wirePrivacyLink();
